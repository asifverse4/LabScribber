// Clean Electron Preload Bridge Context API
window.addEventListener('DOMContentLoaded', () => {
  console.log('Labscribber secure desktop bridge loaded successfully.');
});
