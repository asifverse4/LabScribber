/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { SpectrumData } from '../types';
import { simulateUVVis, simulateNMR, simulateFTIR, simulateRaman, simulatePL, simulateXRD, simulateXPS, simulate13CNMR, simulate2DCOSY } from '../data/simulators';
import { Plus, Trash2, Eye, EyeOff, FileText, Beaker, FileSpreadsheet, Download, Upload } from 'lucide-react';
import * as XLSX from 'xlsx';

interface ObjectBrowserProps {
  datasets: SpectrumData[];
  selectedDataset: SpectrumData | null;
  onDatasetSelected: (ds: SpectrumData) => void;
  onDatasetsUpdated: (list: SpectrumData[]) => void;
}

export const ObjectBrowser: React.FC<ObjectBrowserProps> = ({
  datasets,
  selectedDataset,
  onDatasetSelected,
  onDatasetsUpdated
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const workspaceInputRef = useRef<HTMLInputElement>(null);

  // -----------------------------------------
  // SPECTROMETERS SIMULATION triggers
  // -----------------------------------------
  const handleLoadSim = (type: 'uv' | 'nmr' | '13c' | 'cosy' | 'ftir' | 'raman' | 'pl' | 'xrd' | 'xps') => {
    const listIndex = datasets.length + 1;
    let newDs;
    switch (type) {
      case 'uv':
        newDs = simulateUVVis(listIndex);
        break;
      case 'nmr':
        newDs = simulateNMR(listIndex);
        break;
      case '13c':
        newDs = simulate13CNMR(listIndex);
        break;
      case 'cosy':
        newDs = simulate2DCOSY(listIndex);
        break;
      case 'ftir':
        newDs = simulateFTIR(listIndex);
        break;
      case 'raman':
        newDs = simulateRaman(listIndex);
        break;
      case 'pl':
        newDs = simulatePL(listIndex);
        break;
      case 'xrd':
        newDs = simulateXRD(listIndex);
        break;
      case 'xps':
        newDs = simulateXPS(listIndex);
        break;
    }
    
    // Assign qualitative colors sequentially
    const colors = ['#0ea5e9', '#e11d48', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#14b8a6'];
    newDs.color = colors[datasets.length % colors.length];

    const newList = [...datasets, newDs];
    onDatasetsUpdated(newList);
    onDatasetSelected(newDs);
  };

  // -----------------------------------------
  // SMART INGESTION (EXCEL, CSV, TXT)
  // -----------------------------------------
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((fileObj) => {
      const file = fileObj as File;
      const ext = file.name.split('.').pop()?.toLowerCase();
      const reader = new FileReader();

      reader.onload = (evt) => {
        const data = evt.target?.result;
        if (!data) return;

        try {
          let parsedRows: any[][] = [];

          if (ext === 'xlsx' || ext === 'xls') {
            const workbook = XLSX.read(data, { type: 'binary' });
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            parsedRows = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
          } else {
            // Text/CSV parsing
            const textContent = data as string;
            const lines = textContent.split('\n');
            lines.forEach((line) => {
              // Ignore comment indicators
              if (line.trim().startsWith('#') || line.trim().startsWith('//')) return;
              
              // Split on commas, tabs, or spaces
              const r = line.split(/[,\t]+/).map(s => s.trim());
              const rClean = r.filter(s => s.length > 0);
              if (rClean.length > 1) {
                parsedRows.push(rClean);
              }
            });
          }

          if (parsedRows.length < 2) {
            throw new Error("Columns block empty or insufficient columns found.");
          }

          // Build arrays of clean numerical data columns
          // Try to isolate headers in early lines
          let firstDataRowIdx = 0;
          for (let i = 0; i < parsedRows.length; i++) {
            const counts = parsedRows[i].filter(v => !isNaN(Number(v)) && v !== '').length;
            if (counts >= 2) {
              firstDataRowIdx = i;
              break;
            }
          }

          const headerNames: string[] = [];
          if (firstDataRowIdx > 0) {
            const headerRow = parsedRows[firstDataRowIdx - 1];
            headerRow.forEach((h, hIdx) => {
              headerNames[hIdx] = String(h || `Series ${hIdx}`).trim();
            });
          }

          // Fetch numbers
          const numericalBlock: number[][] = [];
          for (let i = firstDataRowIdx; i < parsedRows.length; i++) {
            const row = parsedRows[i];
            const numRow = row.map(v => Number(v));
            if (numRow.every(v => !isNaN(v))) {
              numericalBlock.push(numRow);
            }
          }

          if (numericalBlock.length < 2) {
            throw new Error("Could not construct discrete coordinate points from block.");
          }

          const colsCount = numericalBlock[0].length;
          const xValues = numericalBlock.map(r => r[0]);

          // Extract columns 1..colsCount - 1 as individual Spectrum lines
          const results: SpectrumData[] = [];
          const colors = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#ef4444', '#14b8a6'];

          for (let colIdx = 1; colIdx < colsCount; colIdx++) {
            const yValues = numericalBlock.map(r => r[colIdx]);
            const colLabel = headerNames[colIdx] || `Series ${colIdx}`;
            const labelSpec = `${colLabel} (${file.name})`;

            const indexValue = datasets.length + results.length;

            const sd: SpectrumData = {
              id: `ing-${Date.now()}-${colIdx}`,
              name: labelSpec,
              technique: file.name.toLowerCase().includes('nmr') ? '1H NMR Spectroscopy' : 'UV-Vis Spectroscopy',
              x_orig: [...xValues],
              y_orig: [...yValues],
              x: [...xValues],
              y_processed: [...yValues],
              color: colors[indexValue % colors.length],
              visible: true,
              lineWidth: 1.5,
              lineStyle: 'solid',
              marker: 'none',
              markerSize: 6,
              peaks: [],
              integrals: [],
              baseline: null,
              fitResult: null,
              fitComponents: null,
              fitResiduals: null,
              isTauc: false,
              taucData: null,
              jobsData: null,
              undoStack: [[...yValues]],
              redoStack: [],
              history: [`[${new Date().toLocaleTimeString()}] Smart-Ingested dataset from file ${file.name}.`]
            };
            results.push(sd);
          }

          if (results.length > 0) {
            const newList = [...datasets, ...results];
            onDatasetsUpdated(newList);
            onDatasetSelected(results[0]);
          }

        } catch (err: any) {
          alert(`Smart Ingestion Failed for ${file.name}:\n${err.message || err}`);
        }
      };

      if (ext === 'xlsx' || ext === 'xls') {
        reader.readAsBinaryString(file);
      } else {
        reader.readAsText(file);
      }
    });

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // -----------------------------------------
  // LOCAL HDF5-LIKE WORKSPACE EXPORTS
  // -----------------------------------------
  const handleSaveWorkspace = () => {
    if (datasets.length === 0) {
      alert("No database objects found to compile.");
      return;
    }

    const payload = JSON.stringify(datasets, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Labscribber_Pro_Workspace_${new Date().toISOString().split('T')[0]}.h5.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLoadWorkspace = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const payload = JSON.parse(evt.target?.result as string);
        if (Array.isArray(payload) && payload.every(d => d.id && d.name)) {
          onDatasetsUpdated(payload);
          if (payload.length > 0) {
            onDatasetSelected(payload[0]);
          }
          alert(`Workspace loaded successfully (${payload.length} objects).`);
        } else {
          throw new Error("Invalid object schema.");
        }
      } catch (err) {
        alert("Load Error: The file is not a valid Labscribber Pro workspace package.");
      }
    };
    reader.readAsText(file);
    if (workspaceInputRef.current) workspaceInputRef.current.value = '';
  };

  // -----------------------------------------
  // TREE CONTROLS
  // -----------------------------------------
  const handleToggleVisible = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const list = datasets.map(d => d.id === id ? { ...d, visible: !d.visible } : d);
    onDatasetsUpdated(list);
  };

  const handleDeleteDataset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const list = datasets.filter(d => d.id !== id);
    onDatasetsUpdated(list);
    if (selectedDataset?.id === id && list.length > 0) {
      onDatasetSelected(list[0]);
    }
  };

  const handleStartRename = (ds: SpectrumData) => {
    setEditingId(ds.id);
    setEditName(ds.name);
  };

  const handleSaveRename = (id: string) => {
    const list = datasets.map(d => d.id === id ? { ...d, name: editName.trim() || d.name } : d);
    onDatasetsUpdated(list);
    setEditingId(null);
  };

  return (
    <div className="flex flex-col gap-5 bg-zinc-900 border border-zinc-800 rounded-lg p-5 text-gray-200">
      
      {/* Workspace Persistence Actions */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-teal-400 mb-2">High-Provenance Workspace</h3>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleSaveWorkspace}
            className="flex items-center gap-1.5 justify-center bg-zinc-800 hover:bg-zinc-700 text-xs font-medium py-2 px-3 border border-zinc-700 rounded text-teal-300 transition-colors"
          >
            <Download size={14} /> Download WS
          </button>
          <button
            onClick={() => workspaceInputRef.current?.click()}
            className="flex items-center gap-1.5 justify-center bg-zinc-800 hover:bg-zinc-700 text-xs font-medium py-2 px-3 border border-zinc-700 rounded text-teal-300 transition-colors"
          >
            <Upload size={14} /> Upload WS
          </button>
        </div>
        <input
          type="file"
          ref={workspaceInputRef}
          onChange={handleLoadWorkspace}
          accept=".json"
          className="hidden"
        />
      </div>

      {/* Local Data File Ingestion */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-teal-400 mb-2">Smart Ingestion Parser</h3>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-500 hover:to-teal-400 text-white font-semibold text-xs py-2.5 px-4 rounded shadow-md transition-all border border-teal-500/20"
        >
          <FileSpreadsheet size={15} /> Ingest File (Excel, CSV, TXT)
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept=".csv,.txt,.xlsx,.xls,.dat"
          multiple
          className="hidden"
        />
      </div>

      {/* Bench Simulators */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-teal-400 mb-2">Instrument Simulator</h3>
        <div className="grid grid-cols-3 gap-1.5">
          <button
            onClick={() => handleLoadSim('uv')}
            title="Ultraviolet-Visible Spectroscopy (200-700 nm)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-sky-400 transition hover:border-sky-500/50"
          >
            <Beaker size={11} className="text-sky-400" /> UV-Vis
          </button>
          <button
            onClick={() => handleLoadSim('ftir')}
            title="Fourier-Transform Infrared (vibrational spectrum, 400-4000 cm-1)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-emerald-400 transition hover:border-emerald-500/50"
          >
            <Beaker size={11} className="text-emerald-400" /> FTIR
          </button>
          <button
            onClick={() => handleLoadSim('raman')}
            title="Raman Scattering carbon/lattice peaks (200-2200 cm-1)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-purple-400 transition hover:border-purple-500/50"
          >
            <Beaker size={11} className="text-purple-400" /> Raman
          </button>
          <button
            onClick={() => handleLoadSim('nmr')}
            title="Proton Spin Couplets NMR shift (0-12 ppm)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-rose-400 transition hover:border-rose-500/50"
          >
            <Beaker size={11} className="text-rose-400" /> 1H NMR
          </button>
          <button
            onClick={() => handleLoadSim('13c')}
            title="Carbon-13 Nuclear Magnetic Resonance (0-220 ppm)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-purple-400 transition hover:border-purple-500/50"
          >
            <Beaker size={11} className="text-purple-400" /> 13C NMR
          </button>
          <button
            onClick={() => handleLoadSim('cosy')}
            title="2D Homonuclear Correlation Spectroscopy (0-10 ppm)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-teal-400 transition hover:border-teal-500/50"
          >
            <Beaker size={11} className="text-teal-400" /> 2D COSY
          </button>
          <button
            onClick={() => handleLoadSim('pl')}
            title="Photoluminescence Bandedge Emission (400-900 nm)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-pink-400 transition hover:border-pink-500/50"
          >
            <Beaker size={11} className="text-pink-400" /> PL peak
          </button>
          <button
            onClick={() => handleLoadSim('xrd')}
            title="Polycrystalline X-ray crystal scattering planes (10-80 deg)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-amber-500 transition hover:border-amber-500/50"
          >
            <Beaker size={11} className="text-amber-500" /> XRD
          </button>
          <button
            onClick={() => handleLoadSim('xps')}
            title="High Resolution Carbon core-level Binding Energies (280-295 eV)"
            className="flex items-center gap-1 justify-center bg-zinc-800 hover:bg-zinc-850 text-[9px] font-medium py-1.5 px-1 border border-zinc-700 rounded text-indigo-400 transition hover:border-indigo-500/50"
          >
            <Beaker size={11} className="text-indigo-400" /> XPS C1s
          </button>
        </div>
      </div>

      {/* Object Tree list */}
      <div className="flex-1 flex flex-col min-h-[160px]">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-teal-400 mb-2">
          Object Browser <span className="text-xxs text-gray-500 normal-case">({datasets.length} series)</span>
        </h3>
        <p className="text-[10px] text-gray-500 mb-2 leading-relaxed">
          Double-click a name to edit. Toggle the eye button to render trace layers in overlays.
        </p>

        {datasets.length > 0 && (
          <div className="flex justify-end gap-1.5 mb-2.5">
            <button
              onClick={() => {
                const list = datasets.map(d => ({ ...d, visible: true }));
                onDatasetsUpdated(list);
              }}
              className="text-[9px] bg-[#27272a] hover:bg-[#3f3f46] text-zinc-300 font-semibold px-2 py-0.5 rounded transition uppercase border border-[#3f3f46] hover:text-teal-400"
            >
              Show All
            </button>
            <button
              onClick={() => {
                const list = datasets.map(d => ({ ...d, visible: false }));
                onDatasetsUpdated(list);
              }}
              className="text-[9px] bg-[#27272a] hover:bg-[#3f3f46] text-zinc-300 font-semibold px-2 py-0.5 rounded transition uppercase border border-[#3f3f46] hover:text-rose-400"
            >
              Hide All
            </button>
            <button
              onClick={() => {
                const list = datasets.filter(d => d.visible);
                onDatasetsUpdated(list);
                if (list.length > 0) {
                  onDatasetSelected(list[0]);
                }
              }}
              title="Purge all elements that are hidden"
              className="text-[9px] bg-[#241515] hover:bg-[#3c2020] text-rose-400 font-semibold px-2 py-0.5 rounded transition uppercase border border-rose-900/30"
            >
              Purge Hidden
            </button>
          </div>
        )}

        {datasets.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center border border-dashed border-zinc-800 rounded p-6 text-center text-gray-500">
            <FileText size={24} className="mb-2 text-gray-600" />
            <span className="text-xs font-medium">Object browser is empty.</span>
            <span className="text-[10px] text-gray-600 mt-1">Ingest columns from Excel or spin up virtual tools.</span>
          </div>
        ) : (
          <div className="flex-1 max-h-[220px] overflow-y-auto border border-zinc-800 rounded bg-zinc-950 divide-y divide-zinc-800 scrollbar-thin scrollbar-thumb-zinc-800">
            {datasets.map((ds) => {
              const works = selectedDataset?.id === ds.id;
              return (
                <div
                  key={ds.id}
                  onClick={() => onDatasetSelected(ds)}
                  onDoubleClick={() => handleStartRename(ds)}
                  className={`flex items-center justify-between py-2 px-3 cursor-pointer group transition-colors select-none ${
                    works ? 'bg-zinc-900 border-l-2 border-teal-500' : 'hover:bg-zinc-900/50'
                  }`}
                >
                  <div className="flex items-center gap-2 flex-1 min-w-0 pr-2">
                    {/* Trace color pill */}
                    <div
                      className="w-2.5 h-2.5 rounded-full shrink-0 shadow-inner"
                      style={{ backgroundColor: ds.color }}
                    />
                    
                    {editingId === ds.id ? (
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onBlur={() => handleSaveRename(ds.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveRename(ds.id);
                          if (e.key === 'Escape') setEditingId(null);
                        }}
                        autoFocus
                        className="bg-zinc-800 border border-teal-500 text-white rounded px-1 py-0.5 text-xs w-full focus:outline-none focus:ring-1 focus:ring-teal-500"
                        onClick={(e) => e.stopPropagation()}
                      />
                    ) : (
                      <span className={`text-xs font-medium truncate ${works ? 'text-teal-400' : 'text-gray-300'}`}>
                        {ds.name}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => handleToggleVisible(ds.id, e)}
                      title="Toggle Visibility"
                      className="hover:text-teal-400 p-1 rounded hover:bg-zinc-800 text-zinc-400 transition"
                    >
                      {ds.visible ? <Eye size={13} /> : <EyeOff size={13} className="text-zinc-500" />}
                    </button>
                    <button
                      onClick={(e) => handleDeleteDataset(ds.id, e)}
                      title="Purge Object"
                      className="hover:text-rose-500 p-1 rounded hover:bg-zinc-800 text-zinc-400 transition"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
