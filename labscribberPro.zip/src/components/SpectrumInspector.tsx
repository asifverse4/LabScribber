/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SpectrumData, JournalStyleType, ViewLayoutMode, PeakData, IntegralData, PCAOutput } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import { generatePythonTkinterCode } from '../data/pyExporter';
import {
  savitzkyGolay,
  movingAverage,
  shirleyBaseline,
  snipBaseline,
  alsBaseline,
  spectralExpertHeuristics,
  fitSpectralPeaks,
  linearRegression,
  runPCASVD
} from '../utils/math';
import {
  Undo,
  Redo,
  RefreshCw,
  Search,
  Sparkles,
  TrendingUp,
  Sliders,
  Maximize2,
  Download,
  FileSpreadsheet,
  Layers,
  ChevronRight,
  Palette,
  Crosshair,
  Grid,
  Loader2,
  Check,
  FileText
} from 'lucide-react';

interface StoichiometryResult {
  ratio: string;
  formula: string;
  desc: string;
}

export function getStoichiometryName(x_max: number): StoichiometryResult {
  if (x_max < 0.1) {
    return {
      ratio: "No Complexation",
      formula: "",
      desc: "Mole fraction is too low to suggest meaningful complex formation or coordination binding."
    };
  }
  if (x_max >= 0.1 && x_max < 0.28) {
    return {
      ratio: "1:3 Host-Guest",
      formula: "[HG₃]",
      desc: "Characteristic of coordination spheres where one central host bonds with three guest coordinating entities or triple-helical architectures."
    };
  } else if (x_max >= 0.28 && x_max < 0.42) {
    return {
      ratio: "1:2 Host-Guest",
      formula: "[HG₂]",
      desc: "Bis-complexation. Encountered in metal-ligand chelates (e.g., ML₂) where two ligands coordinate to one metal ion center."
    };
  } else if (x_max >= 0.42 && x_max < 0.58) {
    return {
      ratio: "1:1 Host-Guest",
      formula: "[HG]",
      desc: "Classic 1:1 stoichiometry with molecular host cavity insertion, charge-transfer interactions, or simple electrostatic pairing."
    };
  } else if (x_max >= 0.58 && x_max < 0.72) {
    return {
      ratio: "2:1 Host-Guest",
      formula: "[H₂G]",
      desc: "Dual host sandwich structures or binuclear metallic centers where a single guest molecule is coordinate-bound by two host molecules."
    };
  } else {
    return {
      ratio: "3:1 Host-Guest",
      formula: "[H₃G]",
      desc: "Consistent with pristine trinuclear cluster coordination complexes or highly aggregated multi-host supra-assembly conformations."
    };
  }
}

interface SpectrumInspectorProps {
  datasets: SpectrumData[];
  selectedDataset: SpectrumData | null;
  onDatasetsUpdated: (list: SpectrumData[]) => void;
  onDatasetSelected: (ds: SpectrumData) => void;

  layoutMode: ViewLayoutMode;
  setLayoutMode: (val: ViewLayoutMode) => void;
  journalStyle: JournalStyleType;
  setJournalStyle: (val: JournalStyleType) => void;
  plotBgColor: string;
  setPlotBgColor: (val: string) => void;
  gridX: boolean;
  setGridX: (val: boolean) => void;
  gridY: boolean;
  setGridY: (val: boolean) => void;
  autoX: boolean;
  setAutoX: (val: boolean) => void;
  autoY: boolean;
  setAutoY: (val: boolean) => void;
  manualXMin: number;
  setManualXMin: (val: number) => void;
  manualXMax: number;
  setManualXMax: (val: number) => void;
  manualYMin: number;
  setManualYMin: (val: number) => void;
  manualYMax: number;
  setManualYMax: (val: number) => void;
  xLabel: string;
  setXLabel: (val: string) => void;
  yLabel: string;
  setYLabel: (val: string) => void;
  showLegend: boolean;
  setShowLegend: (val: boolean) => void;
  legendPos: string;
  setLegendPos: (val: string) => void;
  thickAxes: boolean;
  setThickAxes: (val: boolean) => void;
  dropLines: boolean;
  setDropLines: (val: boolean) => void;
  waterfallOffset: number;
  setWaterfallOffset: (val: number) => void;
  enableInset: boolean;
  setEnableInset: (val: boolean) => void;
  insetXMin: number;
  setInsetXMin: (val: number) => void;
  insetXMax: number;
  setInsetXMax: (val: number) => void;
  enableHighlight: boolean;
  setEnableHighlight: (val: boolean) => void;
  highlightMin: number;
  setHighlightMin: (val: number) => void;
  highlightMax: number;
  setHighlightMax: (val: number) => void;
  interactiveMode: 'navigate' | 'pick' | 'crop' | 'integrate';
  setInteractiveMode: (val: 'navigate' | 'pick' | 'crop' | 'integrate') => void;
  isPremium: boolean;
  exportCount: number;
  setExportCount: React.Dispatch<React.SetStateAction<number>>;
  onTriggerUpgrade: () => void;
  onPreviewCorrectedYChange?: (y: number[] | null) => void;
  onOpenCiteKit?: () => void;

  // Custom Publication extensions
  invertX: boolean;
  setInvertX: (val: boolean) => void;
  invertY: boolean;
  setInvertY: (val: boolean) => void;
  tickStepX: number;
  setTickStepX: (val: number) => void;
  tickStepY: number;
  setTickStepY: (val: number) => void;
  minorTicksCount: number;
  setMinorTicksCount: (val: number) => void;
}

export const SpectrumInspector: React.FC<SpectrumInspectorProps> = ({
  datasets,
  selectedDataset,
  onDatasetsUpdated,
  onDatasetSelected,

  layoutMode,
  setLayoutMode,
  journalStyle,
  setJournalStyle,
  plotBgColor,
  setPlotBgColor,
  gridX,
  setGridX,
  gridY,
  setGridY,
  autoX,
  setAutoX,
  autoY,
  setAutoY,
  manualXMin,
  setManualXMin,
  manualXMax,
  setManualXMax,
  manualYMin,
  isPremium,
  exportCount,
  setExportCount,
  onTriggerUpgrade,
  onOpenCiteKit,
  setManualYMin,
  manualYMax,
  setManualYMax,
  xLabel,
  setXLabel,
  yLabel,
  setYLabel,
  showLegend,
  setShowLegend,
  legendPos,
  setLegendPos,
  thickAxes,
  setThickAxes,
  dropLines,
  setDropLines,
  waterfallOffset,
  setWaterfallOffset,
  enableInset,
  setEnableInset,
  insetXMin,
  setInsetXMin,
  insetXMax,
  setInsetXMax,
  enableHighlight,
  setEnableHighlight,
  highlightMin,
  setHighlightMin,
  highlightMax,
  setHighlightMax,
  interactiveMode,
  setInteractiveMode,
  onPreviewCorrectedYChange,

  // Deconstruct publication settings modifiers
  invertX,
  setInvertX,
  invertY,
  setInvertY,
  tickStepX,
  setTickStepX,
  tickStepY,
  setTickStepY,
  minorTicksCount,
  setMinorTicksCount
}) => {
  const [activeTab, setActiveTab] = useState<'process' | 'batch' | 'analyze' | 'tauc' | 'jobs' | 'style' | 'export'>('process');

  // Job's Plot States
  const [jobsTargetWl, setJobsTargetWl] = useState<string>('340');
  const [jobsSelectedIds, setJobsSelectedIds] = useState<string[]>([]);
  const [customMoleFractions, setCustomMoleFractions] = useState<Record<string, number>>({});

  // Multi-Step Processing State variables
  const [subtractionTarget, setSubtractionTarget] = useState<string>('None');
  const [smoothOpts, setSmoothOpts] = useState({
    enabled: false,
    method: 'Savitzky-Golay',
    window: 11,
    poly: 2,
    deriv: 0
  });
  const [baselineMethod, setBaselineMethod] = useState<'None' | 'Shirley' | 'SNIP' | 'ALS'>('None');
  const [alsLam, setAlsLam] = useState<number>(1e4);
  const [normalizeY, setNormalizeY] = useState<boolean>(false);

  // Batch Processing States
  const [batchSelectedIds, setBatchSelectedIds] = useState<string[]>([]);
  const [batchSmoothEnabled, setBatchSmoothEnabled] = useState<boolean>(false);
  const [batchSmoothMethod, setBatchSmoothMethod] = useState<'Savitzky-Golay' | 'Moving Average'>('Savitzky-Golay');
  const [batchSmoothWindow, setBatchSmoothWindow] = useState<number>(11);
  const [batchSmoothPoly, setBatchSmoothPoly] = useState<number>(2);
  const [batchSmoothDeriv, setBatchSmoothDeriv] = useState<number>(0);
  const [batchBaselineMethod, setBatchBaselineMethod] = useState<'None' | 'Shirley' | 'SNIP' | 'ALS'>('None');
  const [batchAlsLam, setBatchAlsLam] = useState<number>(1e4);
  const [batchNormalizeY, setBatchNormalizeY] = useState<boolean>(false);
  const [batchFromRaw, setBatchFromRaw] = useState<boolean>(true);

  // Peak picking search parameters
  const [peakProminence, setPeakProminence] = useState<number>(0.05);

  // Curve fitting configurations
  const [fitProfile, setFitProfile] = useState<'Gaussian' | 'Lorentzian' | 'Voigt'>('Gaussian');
  const [fitConstraints, setFitConstraints] = useState({
    enforce: false,
    centerTol: 10,
    widthMin: 1.0,
    widthMax: 50.0
  });

  // PCA dialog state representation
  const [pcaResult, setPcaResult] = useState<PCAOutput | null>(null);
  const [isPcaModalOpen, setIsPcaModalOpen] = useState<boolean>(false);

  // Journal high-DPI export configurations
  const [exportDPI, setExportDPI] = useState<300 | 600 | 1200>(300);
  const [exportFormat, setExportFormat] = useState<'png' | 'tiff'>('png');
  const [journalStyleOverride, setJournalStyleOverride] = useState<'ACS' | 'RSC' | 'Nature' | 'Default'>('ACS');

  // PDF Preview State
  const [isPdfPreviewOpen, setIsPdfPreviewOpen] = useState(false);

  // Animated export feedback and floating notifications state
  const [exportStates, setExportStates] = useState<Record<string, 'idle' | 'loading' | 'success'>>({
    highDpi: 'idle',
    svg: 'idle',
    python: 'idle',
    csv: 'idle',
    markdown: 'idle',
    pdf: 'idle'
  });

  interface ExportToast {
    id: string;
    title: string;
    message: string;
    filename: string;
    onClickDownload?: () => void;
  }

  const [toasts, setToasts] = useState<ExportToast[]>([]);

  const triggerToast = (title: string, message: string, filename: string, onClickDownload?: () => void) => {
    const id = Math.random().toString();
    const newToast = { id, title, message, filename, onClickDownload };
    setToasts(prev => [...prev, newToast]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 6000);
  };

  // Real-time ALS baseline corrected preview curves subscription
  useEffect(() => {
    if (activeTab === 'process' && baselineMethod === 'ALS' && onPreviewCorrectedYChange && selectedDataset) {
      const computedBaseline = alsBaseline(selectedDataset.y_processed, alsLam, 0.01, 8);
      const previewCorrected = selectedDataset.y_processed.map((v, i) => v - computedBaseline[i]);
      onPreviewCorrectedYChange(previewCorrected);
    } else if (onPreviewCorrectedYChange) {
      onPreviewCorrectedYChange(null);
    }
  }, [activeTab, baselineMethod, alsLam, selectedDataset, onPreviewCorrectedYChange]);

  if (!selectedDataset) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 text-gray-400 text-center text-xs">
        Select a spectroscopic object index from the browser to unlock the analytical inspector.
      </div>
    );
  }

  const sd = selectedDataset;

  // State undo stack wrapper pushes
  const pushStateUndo = (updatedY: number[], historyAction: string, extraFields: Partial<SpectrumData> = {}) => {
    const list = datasets.map(d => {
      if (d.id === sd.id) {
        const historyText = `[${new Date().toLocaleTimeString()}] ${historyAction}`;
        const newHistory = [...d.history, historyText];
        
        // Push to undo, clear redo stack
        const newUndo = [...d.undoStack, [...d.y_processed]];
        
        return {
          ...d,
          ...extraFields,
          y_processed: updatedY,
          undoStack: newUndo,
          redoStack: [],
          history: newHistory
        };
      }
      return d;
    });
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
  };

  const handleChangeTechnique = (newTech: string) => {
    const list = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          technique: newTech,
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Technique recalibrated to ${newTech}.`]
        };
      }
      return d;
    });
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
  };

  const handleUndo = () => {
    if (sd.undoStack.length <= 1) return;
    const newUndo = [...sd.undoStack];
    const prevY = newUndo.pop()!;
    const newRedo = [...sd.redoStack, [...sd.y_processed]];

    const list = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          y_processed: prevY,
          undoStack: newUndo,
          redoStack: newRedo,
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Process state undone.`],
          fitResult: null,
          fitComponents: null,
          fitResiduals: null
        };
      }
      return d;
    });
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
  };

  const handleRedo = () => {
    if (sd.redoStack.length === 0) return;
    const newRedo = [...sd.redoStack];
    const nextY = newRedo.pop()!;
    const newUndo = [...sd.undoStack, [...sd.y_processed]];

    const list = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          y_processed: nextY,
          undoStack: newUndo,
          redoStack: newRedo,
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Process state redone.`]
        };
      }
      return d;
    });
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
  };

  const handleResetToRaw = () => {
    const list = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          x: [...d.x_orig],
          y_processed: [...d.y_orig],
          baseline: null,
          peaks: [],
          integrals: [],
          fitResult: null,
          fitComponents: null,
          fitResiduals: null,
          isTauc: false,
          taucData: null,
          jobsData: null,
          undoStack: [[...d.y_orig]],
          redoStack: [],
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Reset fully to baseline-original raw data.`]
        };
      }
      return d;
    });
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
  };

  // -----------------------------------------
  // PROCESSING WORKFLOWS
  // -----------------------------------------
  const handleApplyProcess = () => {
    let traceY = [...sd.y_processed];

    // 1. Subtract blank solvent spectrum
    if (subtractionTarget !== 'None') {
      const bgTrace = datasets.find(d => d.id === subtractionTarget);
      if (bgTrace && bgTrace.x.length === sd.x.length) {
        traceY = traceY.map((v, i) => v - bgTrace.y_processed[i]);
      }
    }

    // 2. Applying smoothing/derivative filters
    if (smoothOpts.enabled) {
      if (smoothOpts.method === 'Savitzky-Golay') {
        traceY = savitzkyGolay(traceY, smoothOpts.window, smoothOpts.poly, smoothOpts.deriv);
      } else {
        traceY = movingAverage(traceY, smoothOpts.window);
      }
    }

    // 3. Subtract background baseline model
    let computedBaseline: number[] | null = null;
    if (baselineMethod === 'Shirley') {
      computedBaseline = shirleyBaseline(traceY, 15);
      traceY = traceY.map((v, i) => v - computedBaseline![i]);
    } else if (baselineMethod === 'SNIP') {
      computedBaseline = snipBaseline(traceY, 20);
      traceY = traceY.map((v, i) => v - computedBaseline![i]);
    } else if (baselineMethod === 'ALS') {
      computedBaseline = alsBaseline(traceY, alsLam, 0.01, 8);
      traceY = traceY.map((v, i) => v - computedBaseline![i]);
    }

    // 4. Min/Max Normalize option
    if (normalizeY) {
      const min = Math.min(...traceY);
      const max = Math.max(...traceY);
      const range = max - min || 1e-9;
      traceY = traceY.map(v => (v - min) / range);
    }

    pushStateUndo(
      traceY,
      `Applied multi-step processing: (Smoothing: ${smoothOpts.enabled}, Baseline: ${baselineMethod}, Norm: ${normalizeY})`,
      { baseline: computedBaseline }
    );
  };

  const handleApplyBatchProcess = () => {
    if (batchSelectedIds.length === 0) {
      alert("Please select at least one dataset from the Batch Processor checklist to process.");
      return;
    }

    let updatedCount = 0;
    const updatedList = datasets.map(d => {
      if (batchSelectedIds.includes(d.id)) {
        updatedCount++;
        let traceY = batchFromRaw ? [...d.y_orig] : [...d.y_processed];

        // Apply smoothing
        if (batchSmoothEnabled) {
          if (batchSmoothMethod === 'Savitzky-Golay') {
            traceY = savitzkyGolay(traceY, batchSmoothWindow, batchSmoothPoly, batchSmoothDeriv);
          } else {
            traceY = movingAverage(traceY, batchSmoothWindow);
          }
        }

        // Apply baseline background removal
        let computedBaseline: number[] | null = null;
        if (batchBaselineMethod === 'Shirley') {
          computedBaseline = shirleyBaseline(traceY, 15);
          traceY = traceY.map((v, i) => v - computedBaseline![i]);
        } else if (batchBaselineMethod === 'SNIP') {
          computedBaseline = snipBaseline(traceY, 20);
          traceY = traceY.map((v, i) => v - computedBaseline![i]);
        } else if (batchBaselineMethod === 'ALS') {
          computedBaseline = alsBaseline(traceY, batchAlsLam, 0.01, 8);
          traceY = traceY.map((v, i) => v - computedBaseline![i]);
        }

        // Apply min/max normalization
        if (batchNormalizeY) {
          const min = Math.min(...traceY);
          const max = Math.max(...traceY);
          const range = max - min || 1e-9;
          traceY = traceY.map(v => (v - min) / range);
        }

        const historyActionText = `Batch processed: (Smooth: ${batchSmoothEnabled ? batchSmoothMethod : 'None'}, Baseline: ${batchBaselineMethod}, Norm: ${batchNormalizeY}, BaseSrc: ${batchFromRaw ? 'raw_orig' : 'last_processed'})`;
        const historyText = `[${new Date().toLocaleTimeString()}] ${historyActionText}`;

        return {
          ...d,
          y_processed: traceY,
          baseline: computedBaseline,
          undoStack: [...d.undoStack, [...d.y_processed]],
          redoStack: [],
          history: [...d.history, historyText]
        };
      }
      return d;
    });

    onDatasetsUpdated(updatedList);

    // Update active focus selected dataset if it was modified in the batch
    const currentSelectedInList = updatedList.find(d => d.id === sd.id);
    if (currentSelectedInList) {
      onDatasetSelected(currentSelectedInList);
    }

    triggerToast(
      "Batch Processing Complete",
      `Simultaneously computed identical baseline, smoothing, and normalization pipelines for ${updatedCount} selected spectra.`,
      `batch_output_${Date.now().toString().slice(-6)}.csv`
    );
  };

  // -----------------------------------------
  // ANALYTIC ACTIONS
  // -----------------------------------------

  // Auto detect local peaks
  const handleAutoPickPeaks = () => {
    const listPeaks: PeakData[] = [];
    const len = sd.x.length;
    
    // Scan local maximums matching prominence thresholds
    for (let i = 2; i < len - 2; i++) {
      const cy = sd.y_processed[i];
      if (cy > sd.y_processed[i-1] && cy > sd.y_processed[i-2] && cy > sd.y_processed[i+1] && cy > sd.y_processed[i+2]) {
        // Prominence barrier check
        const baseHeight = Math.min(sd.y_processed[i-2], sd.y_processed[i+2]);
        if (cy - baseHeight >= peakProminence && cy > 0.02) {
          listPeaks.push({
            id: `pk-${Date.now()}-${i}`,
            x: sd.x[i],
            y: cy,
            label: '',
            confidence: 0,
            dx: 0,
            dy: 40
          });
        }
      }
    }

    const updatedList = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          peaks: [...d.peaks, ...listPeaks],
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Auto-detected ${listPeaks.length} peaks with prominence >= ${peakProminence}.`]
        };
      }
      return d;
    });
    onDatasetsUpdated(updatedList);
    onDatasetSelected(updatedList.find(d => d.id === sd.id)!);
  };

  // Mnova expert labeling machine
  const handleMnovaExpertSystems = () => {
    if (sd.peaks.length === 0) {
      alert("No peaks detected. Pick peaks manually or run auto-detect peaks first.");
      return;
    }

    const assigned = sd.peaks.map(p => {
      const { label, confidence } = spectralExpertHeuristics(sd.technique, p.x);
      return { ...p, label, confidence };
    });

    const updatedList = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          peaks: assigned,
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Applied Mnova heuristic database assignments.`]
        };
      }
      return d;
    });
    onDatasetsUpdated(updatedList);
    onDatasetSelected(updatedList.find(d => d.id === sd.id)!);
  };

  // Curve Multi deconvolution fit
  const handleRunCurveDeconvolution = () => {
    if (sd.peaks.length === 0) {
      alert("Identify peaks coordinates as initial seed guesses before deconvolving.");
      return;
    }

    try {
      const { fitResult, fitComponents, fitResiduals } = fitSpectralPeaks(
        sd.x,
        sd.y_processed,
        sd.peaks,
        fitProfile,
        fitConstraints
      );

      const list = datasets.map(d => {
        if (d.id === sd.id) {
          return {
            ...d,
            fitResult,
            fitComponents,
            fitResiduals,
            history: [...d.history, `[${new Date().toLocaleTimeString()}] Successfully fit ${d.peaks.length} ${fitProfile} decay components.`]
          };
        }
        return d;
      });
      onDatasetsUpdated(list);
      onDatasetSelected(list.find(d => d.id === sd.id)!);
    } catch (err: any) {
      alert(`Optimization Fitting Interrupted: ${err.message || err}`);
    }
  };

  const handleDisableTaucPlot = () => {
    const list = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          x: [...d.x_orig],
          y_processed: [...d.y_orig],
          isTauc: false,
          taucData: null,
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Disabled semiconductor Tauc plot; restored original wavelength dimensions.`]
        };
      }
      return d;
    });
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
    setXLabel("Wavelength (nm)");
    setYLabel("Absorbance");
    setAutoX(true);
    setAutoY(true);
  };

  // Tauc Extrapolator
  const handleTaucTransformation = (transition: 'direct' | 'indirect') => {
    // Tauc: E = 1240 / lambda, y = (Alpha * E)^(2 or 0.5)
    if (!sd.technique.toLowerCase().includes('uv')) {
      alert("Tauc transformations require semiconductor absorbance datasets (UV-Vis Spectrum lines).");
      return;
    }

    const tX = sd.x.map(wl => 1240 / wl).reverse();
    const tYRaw = sd.y_processed.map((alpha, i) => {
      const e = 1240 / sd.x[i];
      const prod = alpha * e;
      return transition === 'direct' ? Math.pow(prod, 2) : Math.pow(prod, 0.5);
    }).reverse();

    // Automatically locate primary linear tangent range via point of highest first derivative slope
    const derivY: number[] = [];
    for (let i = 1; i < tX.length - 1; i++) {
       derivY.push((tYRaw[i+1] - tYRaw[i-1]) / (tX[i+1] - tX[i-1]));
    }
    const maxDerivIdx = derivY.indexOf(Math.max(...derivY)) + 1;
    
    // Fit central quadrant
    const segmentSize = 8;
    const startIdx = Math.max(0, maxDerivIdx - Math.floor(segmentSize/2));
    const fitX = tX.slice(startIdx, startIdx + segmentSize);
    const fitY = tYRaw.slice(startIdx, startIdx + segmentSize);

    const { m, c } = linearRegression(fitX, fitY);
    const eg = -c / m;

    const list = datasets.map(d => {
      if (d.id === sd.id) {
        return {
          ...d,
          x: [...tX],
          y_processed: [...tYRaw],
          isTauc: true,
          taucData: { m, c, eg, x_start: tX[maxDerivIdx] - 0.4, x_end: eg, transition },
          history: [...d.history, `[${new Date().toLocaleTimeString()}] Executed semiconductor Tauc Plot (${transition}). Eg Extrapolation = ${eg.toFixed(3)} eV.`],
          peaks: [] // clear constraints
        };
      }
      return d;
    });
    
    onDatasetsUpdated(list);
    onDatasetSelected(list.find(d => d.id === sd.id)!);
    
    // Auto rescale view axes to focus on semiconductor band edges
    setXLabel("Energy Offset, hν (eV)");
    setYLabel(transition === 'direct' ? '(αhν)²' : '(αhν)⁰⁵');
    setAutoX(false);
    setManualXMin(Math.max(0, eg - 1.2));
    setManualXMax(eg + 1.8);
  };

  // Continuous Job's plot stoichiometric intercepts
  const handleCreateJobsPlot = () => {
    const listVis = datasets.filter(d => d.visible && d.id !== sd.id);
    if (listVis.length < 3) {
      alert("Job's Stoichiometry Plot of Continuous Variations requires at least 3 separate mole fraction spectra visible.");
      return;
    }

    // Ask user for target coordinate wavelength
    const targetWlStr = prompt("Specify analysis molecular target coordinates (e.g. wavelength/shift peak):", "340");
    if (!targetWlStr) return;
    const targetWl = Number(targetWlStr);
    if (isNaN(targetWl)) return;

    // Linearly assign mole fraction arrays [0, 1] across dataset count
    const count = listVis.length;
    const xFractions = listVis.map((_, i) => i / (count - 1));
    
    // For each visible dataset, interpolate the absorbance value at targeted coordinate
    const deltaY = listVis.map((d, dIdx) => {
      // Find nearest coordinate point
      let nearestIdx = 0;
      let diff = Infinity;
      for (let i = 0; i < d.x.length; i++) {
        const dX = Math.abs(d.x[i] - targetWl);
        if (dX < diff) { diff = dX; nearestIdx = i; }
      }
      const absVal = d.y_processed[nearestIdx] || 0;
      return absVal;
    });

    // Subtract baseline straight line from first (0) to last (1) to find deviations
    const startY = deltaY[0];
    const endY = deltaY[count - 1];
    const devY = deltaY.map((y, i) => {
      const baselineVal = startY * (1 - xFractions[i]) + endY * xFractions[i];
      return y - baselineVal;
    });

    // Find intersection of left slope linear fit and right slope linear fit
    const maxIdx = devY.indexOf(Math.max(...devY));
    const leftX = xFractions.slice(0, maxIdx + 1);
    const leftY = devY.slice(0, maxIdx + 1);
    const rightX = xFractions.slice(maxIdx);
    const rightY = devY.slice(maxIdx);

    const fitLeft = linearRegression(leftX, leftY);
    const fitRight = linearRegression(rightX, rightY);

    const x_int = (fitRight.c - fitLeft.c) / (fitLeft.m - fitRight.m);
    const y_int = fitLeft.m * x_int + fitLeft.c;

    const jobsSpectra: SpectrumData = {
      id: `jobs-${Date.now()}`,
      name: `Job's Plot (${targetWl} nm)`,
      technique: "Job's Plot",
      x_orig: [...xFractions],
      y_orig: [...devY],
      x: [...xFractions],
      y_processed: [...devY],
      color: '#e11d48',
      visible: true,
      lineWidth: 2.0,
      lineStyle: 'solid',
      marker: 'circle',
      markerSize: 8,
      peaks: [],
      integrals: [],
      baseline: null,
      fitResult: null,
      fitComponents: null,
      fitResiduals: null,
      isTauc: false,
      taucData: null,
      jobsData: { x_int, y_int, m1: fitLeft.m, c1: fitLeft.c, r2_1: fitLeft.r2, m2: fitRight.m, c2: fitRight.c, r2_2: fitRight.r2 },
      undoStack: [[...devY]],
      redoStack: [],
      history: [`[${new Date().toLocaleTimeString()}] Constructed continuous variation Stoichiometry Job's Plot at target ${targetWl}. Intercept mole fraction = ${x_int.toFixed(3)}.`]
    };

    onDatasetsUpdated([...datasets, jobsSpectra]);
    onDatasetSelected(jobsSpectra);
    
    setXLabel("Mole Fraction (X)");
    setYLabel("Δ Absorbance Deviation");
    setAutoX(false);
    setManualXMin(0);
    setManualXMax(1);
  };

  // Automated continuous Job's plot stoichiometric ratio calculations
  const handleApplyJobsMethod = (targetWlVal?: number) => {
    const wlInput = targetWlVal ?? Number(jobsTargetWl);
    if (isNaN(wlInput)) {
      alert("Invalid target coordinate numerical wavelength reference.");
      return;
    }

    // Filter to selected datasets if any are selected, otherwise fallback to visible ones
    let selectedList = datasets.filter(d => jobsSelectedIds.includes(d.id));
    if (selectedList.length < 3) {
      // Fallback: use visible ones
      selectedList = datasets.filter(d => d.visible && d.id !== sd.id && d.technique !== "Job's Plot");
    }

    if (selectedList.length < 3) {
      alert("Job's Method continuous variation analysis requires selecting at least 3 datasets.");
      return;
    }

    const count = selectedList.length;
    // Assign mole fractions. If custom mole fraction exists, use it; otherwise assign linear spacing.
    const xFractions = selectedList.map((d, i) => {
      if (customMoleFractions[d.id] !== undefined) {
        return customMoleFractions[d.id];
      }
      return i / (count - 1);
    });

    // Extract absorbance at closest y value
    const deltaY = selectedList.map((d) => {
      let nearestIdx = 0;
      let diff = Infinity;
      for (let i = 0; i < d.x.length; i++) {
        const dX = Math.abs(d.x[i] - wlInput);
        if (dX < diff) {
          diff = dX;
          nearestIdx = i;
        }
      }
      return d.y_processed[nearestIdx] || 0;
    });

    // Subtract baseline straight line from first (0) to last (1) to calculate deviation
    const startY = deltaY[0];
    const endY = deltaY[count - 1];
    const devY = deltaY.map((y, i) => {
      const minX = xFractions[0];
      const maxX = xFractions[count - 1];
      const rangeX = maxX - minX || 1;
      const t = (xFractions[i] - minX) / rangeX;
      const baselineVal = startY * (1 - t) + endY * t;
      return y - baselineVal;
    });

    // Perform dual slope linear fitting
    let maxIdx = 0;
    let maxVal = -Infinity;
    for (let i = 0; i < devY.length; i++) {
      if (devY[i] > maxVal) {
        maxVal = devY[i];
        maxIdx = i;
      }
    }

    const leftX = xFractions.slice(0, Math.max(2, maxIdx + 1));
    const leftY = devY.slice(0, Math.max(2, maxIdx + 1));
    const rightX = xFractions.slice(Math.min(count - 2, maxIdx));
    const rightY = devY.slice(Math.min(count - 2, maxIdx));

    const fitLeft = linearRegression(leftX, leftY);
    const fitRight = linearRegression(rightX, rightY);

    const x_int = (fitRight.c - fitLeft.c) / (fitLeft.m - fitRight.m);
    const y_int = fitLeft.m * x_int + fitLeft.c;

    const jobsSpectra: SpectrumData = {
      id: `jobs-${Date.now()}`,
      name: `Job's Plot (${wlInput} nm)`,
      technique: "Job's Plot",
      x_orig: [...xFractions],
      y_orig: [...devY],
      x: [...xFractions],
      y_processed: [...devY],
      color: '#e11d48',
      visible: true,
      lineWidth: 2.0,
      lineStyle: 'solid',
      marker: 'circle',
      markerSize: 8,
      peaks: [],
      integrals: [],
      baseline: null,
      fitResult: null,
      fitComponents: null,
      fitResiduals: null,
      isTauc: false,
      taucData: null,
      jobsData: { x_int, y_int, m1: fitLeft.m, c1: fitLeft.c, r2_1: fitLeft.r2, m2: fitRight.m, c2: fitRight.c, r2_2: fitRight.r2 },
      undoStack: [[...devY]],
      redoStack: [],
      history: [`[${new Date().toLocaleTimeString()}] Calculated Job's Method stoichiometry plot at target coordinate ${wlInput} nm. Peak intercept at mole fraction X = ${x_int.toFixed(3)}.`]
    };

    onDatasetsUpdated([...datasets, jobsSpectra]);
    onDatasetSelected(jobsSpectra);

    setXLabel("Mole Fraction (X)");
    setYLabel("Δ Absorbance Deviation");
    setAutoX(false);
    setManualXMin(0);
    setManualXMax(1);

    triggerToast(
      "Job's Stoichiometry Plot Created",
      `Calculated stoichiometry mole fraction intercept: ${x_int.toFixed(3)} at target peak ${wlInput}.`,
      `jobs_method_plot_${Date.now().toString().slice(-6)}.csv`
    );
  };

  // -----------------------------------------
  // MULTIVARIATE PRINCIPAL COMPONENT ANALYSIS
  // -----------------------------------------
  const handleCalculatePCA = () => {
    const listVis = datasets.filter(d => d.visible);
    if (listVis.length < 2) {
      alert("Multivariate Principal Component Analysis requires at least 2 trace layers visible.");
      return;
    }

    try {
      // align grids to visible dataset 0 coordinates
      const refGridX = listVis[0].x;
      const matrix: number[][] = [];

      listVis.forEach(ds => {
        // interpolate to share the grid
        const pointsY = refGridX.map(gridX => {
          let low = 0, high = ds.x.length - 1;
          if (gridX <= ds.x[0]) return ds.y_processed[0];
          if (gridX >= ds.x[high]) return ds.y_processed[high];
          while (high - low > 1) {
            const mid = Math.floor((low + high) / 2);
            if (ds.x[mid] <= gridX) low = mid;
            else high = mid;
          }
          const ratio = (gridX - ds.x[low]) / (ds.x[high] - ds.x[low]);
          return ds.y_processed[low] + ratio * (ds.y_processed[high] - ds.y_processed[low]);
        });
        matrix.push(pointsY);
      });

      const output = runPCASVD(matrix, refGridX);
      setPcaResult(output);
      setIsPcaModalOpen(true);
    } catch (err: any) {
      alert(`PCA Breakdown failed: ${err.message || err}`);
    }
  };

  // -----------------------------------------
  // SCIENTIFIC EXPORT REPORTS
  // -----------------------------------------
  const handleExportCSVReport = () => {
    setExportStates(prev => ({ ...prev, csv: 'loading' }));

    setTimeout(() => {
      try {
        let rows = 'Wavelength/Coordinate,Intensity,Smoothed/Processed';
        if (sd.baseline) rows += ',ComputedBaseline';
        if (sd.fitResult) rows += ',CumulativeCurveFit';
        rows += '\n';

        for (let i = 0; i < sd.x.length; i++) {
          rows += `${sd.x[i]},${sd.y_orig[i]},${sd.y_processed[i]}`;
          if (sd.baseline) rows += `,${sd.baseline[i]}`;
          if (sd.fitResult) rows += `,${sd.fitResult[i]}`;
          rows += '\n';
        }

        const blob = new Blob([rows], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const filename = `${sd.name}_analytical_spectra_export.csv`;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        setExportStates(prev => ({ ...prev, csv: 'success' }));

        triggerToast(
          "Tabular CSV Exported",
          "Generated complete rows matching interpolated curves, historical baseline records, and fitting data.",
          filename,
          () => {
            const reLink = document.createElement('a');
            reLink.href = url;
            reLink.download = filename;
            document.body.appendChild(reLink);
            reLink.click();
            document.body.removeChild(reLink);
          }
        );

        setTimeout(() => {
          setExportStates(prev => ({ ...prev, csv: 'idle' }));
        }, 3000);
      } catch (err: any) {
        setExportStates(prev => ({ ...prev, csv: 'idle' }));
        alert("Failed to export CSV: " + (err.message || err));
      }
    }, 750);
  };

  const handleExportMarkdownReport = () => {
    setExportStates(prev => ({ ...prev, markdown: 'loading' }));

    setTimeout(() => {
      try {
        let report = `# LABSCRIBBER SPECTRAFORGE REPORT\n\n`;
        report += `**Dataset Index:** ${sd.name}\n`;
        report += `**Ingested Tool:** ${sd.technique}\n`;
        report += `**Timestamp:** ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}\n\n`;

        report += `## 1. Trace Modifications History Logs\n`;
        sd.history.forEach(log => {
          report += `- ${log}\n`;
        });

        if (sd.peaks.length > 0) {
          report += `\n## 2. Detected Peak Marks & Molecular Assignments\n\n`;
          report += `| Coordinate (X) | Abs/Y Value | Expert System Interpretation | Confidence |\n`;
          report += `|---|---|---|---|\n`;
          sd.peaks.forEach(p => {
            report += `| ${p.x.toFixed(3)} | ${p.y.toFixed(4)} | ${p.label || 'Unassigned'} | ${(p.confidence * 100).toFixed(0)}% |\n`;
          });
        }

        if (sd.integrals.length > 0) {
          report += `\n## 3. Shaded Active Area Integrations\n\n`;
          report += `| Left Bounds (Min) | Right Bounds (Max) | Integrated Spectral Area |\n`;
          report += `|---|---|---|\n`;
          sd.integrals.forEach(intg => {
            report += `| ${intg.xmin.toFixed(3)} | ${intg.xmax.toFixed(3)} | ${intg.area.toExponential(4)} |\n`;
          });
        }

        if (sd.isTauc && sd.taucData) {
          report += `\n## 4. Solid-State Semiconductor Physics\n\n`;
          report += `- **Optical transition profile:** ${sd.taucData.transition} transition model\n`;
          report += `- **Extrapolated Tauc Bandgap (Eg):** **${sd.taucData.eg.toFixed(3)} eV**\n`;
          report += `- **Regression correlation coefficients (R2):** ${(sd.taucData.m * sd.taucData.eg + sd.taucData.c).toFixed(4)} residual offset\n`;
        }

        const blob = new Blob([report], { type: 'text/markdown;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const filename = `${sd.name}_spectroscopic_provenance_report.md`;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        setExportStates(prev => ({ ...prev, markdown: 'success' }));

        triggerToast(
          "Academic Report Downloaded",
          "Successfully compiled full spectral history, peaks database, active integrals, and optical transition statistics into standard Markdown (.md).",
          filename,
          () => {
            const reLink = document.createElement('a');
            reLink.href = url;
            reLink.download = filename;
            document.body.appendChild(reLink);
            reLink.click();
            document.body.removeChild(reLink);
          }
        );

        setTimeout(() => {
          setExportStates(prev => ({ ...prev, markdown: 'idle' }));
        }, 3000);
      } catch (err: any) {
        setExportStates(prev => ({ ...prev, markdown: 'idle' }));
        alert("Failed to export report: " + (err.message || err));
      }
    }, 750);
  };

  const handleExportPDFReport = () => {
    setExportStates(prev => ({ ...prev, pdf: 'loading' }));

    setTimeout(() => {
      try {
        const doc = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4'
        });

        // Common draw helper for footer on a page
        const addFooter = (pageNum: number, totalPages: number) => {
          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(115, 115, 115); // text-zinc-500
          doc.setDrawColor(228, 228, 231); // zinc-200
          doc.line(15, 280, 195, 280);
          doc.text(`Page ${pageNum} of ${totalPages}`, 195, 285, { align: 'right' });
          doc.text(`SpectraForge Workstation Academic Report - Confidential & Authenticated spectroscopic analysis document`, 15, 285);
        };

        const totalPages = 3;

        // -----------------------------------------
        // PAGE 1: HEADER & SPECTRUM PLOT & METADATA
        // -----------------------------------------

        // Stylized top banner
        doc.setFillColor(20, 184, 166); // Teal
        doc.rect(15, 15, 180, 4, 'F');

        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(18);
        doc.setTextColor(24, 24, 27); // text-zinc-900 / dark graphite
        doc.text("SPECTROGRAPHIC PROVENANCE REPORT", 15, 28);

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(115, 115, 115); // text-zinc-500
        doc.text(`Generated: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()} (UTC Local Time)`, 15, 33);
        doc.text("SpectraForge Academic Suite v1.0.0", 195, 33, { align: 'right' });

        // Line divider
        doc.setDrawColor(228, 228, 231); // zinc-200
        doc.setLineWidth(0.5);
        doc.line(15, 37, 195, 37);

        // Metadata box
        doc.setFillColor(244, 244, 245); // zinc-100 gray card
        doc.rect(15, 42, 180, 36, 'F');
        doc.setDrawColor(212, 212, 216); // zinc-300
        doc.rect(15, 42, 180, 36, 'S');

        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(9, 9, 11); // deep charcoal
        doc.text("DATASET METADATA PROFILE", 20, 48);

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(63, 63, 70); // zinc-700
        
        doc.setFont('Helvetica', 'bold');
        doc.text("Dataset Index Name:", 20, 54);
        doc.setFont('Helvetica', 'normal');
        doc.text(sd.name || "N/A", 60, 54);

        doc.setFont('Helvetica', 'bold');
        doc.text("Spectroscopic Method:", 20, 60);
        doc.setFont('Helvetica', 'normal');
        doc.text(sd.technique || "N/A", 60, 60);

        doc.setFont('Helvetica', 'bold');
        doc.text("Coordinates Count (X, Y):", 20, 66);
        doc.setFont('Helvetica', 'normal');
        doc.text(`${sd.x.length} physical datapoints sampled`, 60, 66);

        // Column 2 inside metadata card
        doc.setFont('Helvetica', 'bold');
        doc.text("DPI Layout Directive:", 115, 54);
        doc.setFont('Helvetica', 'normal');
        doc.text(`${journalStyleOverride} CSS Rule active`, 154, 54);

        doc.setFont('Helvetica', 'bold');
        doc.text("Calculated Peak Marks:", 115, 60);
        doc.setFont('Helvetica', 'normal');
        doc.text(`${sd.peaks.length} marks registered`, 154, 60);

        doc.setFont('Helvetica', 'bold');
        doc.text("Active Shaded Areas:", 115, 66);
        doc.setFont('Helvetica', 'normal');
        doc.text(`${sd.integrals.length} segments computed`, 154, 66);

        doc.setFont('Helvetica', 'bold');
        doc.text("State of Calibration:", 20, 72);
        doc.setFont('Helvetica', 'normal');
        doc.text(`Absorbance/Intensity normalized - High Precision Baseline subtracted`, 60, 72);

        // Section: The Graph
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(13, 148, 136); // Teal-600
        doc.text("1. Experimental Waveform Signal & Fitted Curve", 15, 87);

        // Rendering state plot canvas
        const plotDataUrl = (window as any).getPlotCanvasDataURL ? (window as any).getPlotCanvasDataURL() : null;
        if (plotDataUrl) {
          // Canvas aspect ratio is roughly 800x480 (~1.66). Drawing at 180 width x 108 height gives perfect ratio.
          doc.setFillColor(24, 24, 27); // Dark frame matching the dark look
          doc.rect(15, 92, 180, 108, 'F');
          doc.addImage(plotDataUrl, 'PNG', 15, 92, 180, 108);
          // border outline
          doc.setDrawColor(212, 212, 216);
          doc.rect(15, 92, 180, 108, 'S');
        } else {
          doc.setDrawColor(228, 228, 231);
          doc.rect(15, 92, 180, 108, 'S');
          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(10);
          doc.setTextColor(161, 161, 170);
          doc.text("Calculated plot canvas preview could not be captured.", 105, 146, { align: 'center' });
        }

        // Add a small commentary text below graph
        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(82, 82, 91); // zinc-600
        doc.text("Figure 1: Mathematical interpolation curve displaying pristine baseline subtraction models (e.g. SNIP/Shirley/ALS),", 15, 208);
        doc.text("integrated signal regions, and marked peak states. Drawn natively in web standards and validated for publication review.", 15, 213);

        addFooter(1, totalPages);

        // -----------------------------------------
        // PAGE 2: EXPERT PEAKS MARKERS & AREA TABLES
        // -----------------------------------------
        doc.addPage();

        // Small top header
        doc.setFillColor(20, 184, 166);
        doc.rect(15, 15, 180, 1.5, 'F');
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(115, 115, 115);
        doc.text("SPECTROGRAPHIC PROVENANCE REPORT", 15, 22);
        doc.text(`Dataset: ${sd.name}`, 195, 22, { align: 'right' });
        doc.setDrawColor(228, 228, 231);
        doc.line(15, 24, 195, 24);

        // Section: Peak Data Table
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(13, 148, 136); // Teal-600
        doc.text("2. Multi-Peak Spectral Marks & Molecular Assignments", 15, 33);

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(82, 82, 91);
        doc.text("The tables below detail peak detections calculated through expert heuristics and regression fit residuals.", 15, 38);

        // Header for Peak Table
        let tableY = 43;
        doc.setFillColor(244, 244, 245);
        doc.rect(15, tableY, 180, 7, 'F');
        doc.setDrawColor(212, 212, 216);
        doc.line(15, tableY + 7, 195, tableY + 7);

        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(9, 9, 11);
        doc.text("Mark ID", 18, tableY + 4.5);
        doc.text("Coordinate (X-units)", 37, tableY + 4.5);
        doc.text("Absorbance (Y-int)", 75, tableY + 4.5);
        doc.text("Transition Label", 115, tableY + 4.5);
        doc.text("Confidence Index (%)", 160, tableY + 4.5);

        tableY += 7;

        if (sd.peaks.length === 0) {
          doc.setFont('Helvetica', 'normal');
          doc.text("No custom peak markers detected or loaded for this spectral dataset.", 20, tableY + 6);
          tableY += 12;
        } else {
          sd.peaks.forEach((p, idx) => {
            if (tableY > 125) return; // Prevent table overflow (limit layout peaks)
            doc.setFont('Helvetica', 'normal');
            doc.text(`Peak #${idx + 1}`, 18, tableY + 5);
            doc.text(`${p.x.toFixed(3)}`, 37, tableY + 5);
            doc.text(`${p.y.toFixed(4)}`, 75, tableY + 5);
            doc.text(`${p.label || "Unassigned transition"}`, 115, tableY + 5);
            doc.text(`${(p.confidence * 100).toFixed(0)}% confidence`, 160, tableY + 5);

            // subtle gray separating line
            doc.setDrawColor(244, 244, 245);
            doc.line(15, tableY + 7, 195, tableY + 7);
            tableY += 7;
          });
        }

        // Section: Integrations Table
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(13, 148, 136);
        doc.text("3. High-Precision Shaded Area Integrations", 15, tableY + 12);

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(82, 82, 91);
        doc.text("Provides integration mathematical summaries computed over custom highlighted bounds segments.", 15, tableY + 17);

        tableY += 21;

        // Header for Integrations Table
        doc.setFillColor(244, 244, 245);
        doc.rect(15, tableY, 180, 7, 'F');
        doc.setDrawColor(212, 212, 216);
        doc.line(15, tableY + 7, 195, tableY + 7);

        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(9, 9, 11);
        doc.text("Segment Index", 18, tableY + 4.5);
        doc.text("Left Margin Bound (Min)", 48, tableY + 4.5);
        doc.text("Right Margin Bound (Max)", 98, tableY + 4.5);
        doc.text("Computed Spectral Area (Y*X)", 145, tableY + 4.5);

        tableY += 7;

        if (sd.integrals.length === 0) {
          doc.setFont('Helvetica', 'normal');
          doc.text("No integration boundary shaded regions calculated for this spectral sample.", 20, tableY + 6);
        } else {
          sd.integrals.forEach((intg, idx) => {
            if (tableY > 260) return; // overflow check
            doc.setFont('Helvetica', 'normal');
            doc.text(`Segment ${idx + 1}`, 18, tableY + 5);
            doc.text(`${intg.xmin.toFixed(3)} units`, 48, tableY + 5);
            doc.text(`${intg.xmax.toFixed(3)} units`, 98, tableY + 5);
            doc.text(`${intg.area.toExponential(5)}`, 145, tableY + 5);

            // subtle separators
            doc.setDrawColor(244, 244, 245);
            doc.line(15, tableY + 7, 195, tableY + 7);
            tableY += 7;
          });
        }

        addFooter(2, totalPages);

        // -----------------------------------------
        // PAGE 3: TAUC BANDGAP & HISTORY LOGS
        // -----------------------------------------
        doc.addPage();

        // Header
        doc.setFillColor(20, 184, 166);
        doc.rect(15, 15, 180, 1.5, 'F');
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(115, 115, 115);
        doc.text("SPECTROGRAPHIC PROVENANCE REPORT", 15, 22);
        doc.text(`Dataset: ${sd.name}`, 195, 22, { align: 'right' });
        doc.setDrawColor(228, 228, 231);
        doc.line(15, 24, 195, 24);

        let curY = 32;

        // Solid-State Physics Section
        if (sd.isTauc && sd.taucData) {
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(11);
          doc.setTextColor(13, 148, 136);
          doc.text("4. Solid-State Semiconductor Physics (Tauc Fit)", 15, curY);

          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(8.5);
          doc.setTextColor(82, 82, 91);
          doc.text("Extrapolated bandgap transition model based on photon energy values and absorption coefficients.", 15, curY + 5);

          // Details Card
          doc.setFillColor(244, 244, 245);
          doc.rect(15, curY + 9, 180, 24, 'F');
          doc.setDrawColor(212, 212, 216);
          doc.rect(15, curY + 9, 180, 24, 'S');

          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(9, 9, 11);
          
          doc.text("Optical transition profile:", 20, curY + 15);
          doc.setFont('Helvetica', 'normal');
          doc.text(`${sd.taucData.transition} transition model`, 70, curY + 15);

          doc.setFont('Helvetica', 'bold');
          doc.text("Extrapolated Tauc Bandgap (Eg):", 20, curY + 21);
          doc.setFont('Helvetica', 'normal');
          doc.setTextColor(13, 148, 136); // Teal highlight
          doc.setFont('Helvetica', 'bold');
          doc.text(`${sd.taucData.eg.toFixed(3)} eV`, 70, curY + 21);
          doc.setTextColor(9, 9, 11);
          doc.setFont('Helvetica', 'normal');

          doc.setFont('Helvetica', 'bold');
          doc.text("Regression Linear Formula:", 20, curY + 27);
          doc.setFont('Helvetica', 'normal');
          doc.text(`y = ${sd.taucData.m.toExponential(3)} * x + ${sd.taucData.c.toExponential(3)}`, 70, curY + 27);

          doc.setFont('Helvetica', 'bold');
          doc.text("Goodness-of-Fit Coefficient R2:", 115, curY + 15);
          doc.setFont('Helvetica', 'normal');
          doc.text(`Residual offset certified`, 160, curY + 15);

          curY += 42;
        } else {
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(11);
          doc.setTextColor(13, 148, 136);
          doc.text("4. Semiconductor Physical States", 15, curY);
          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(9);
          doc.setTextColor(115, 115, 115);
          doc.text("No active Solid-State Tauc bandgap analysis is toggled for this sample.", 15, curY + 5);
          curY += 16;
        }

        // Section: Processing History Logs
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(13, 148, 136);
        doc.text("5. Scientific Processing History Logs", 15, curY);

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(82, 82, 91);
        doc.text("Prism pipeline calibration actions and baseline subtraction sequence logs.", 15, curY + 5);

        curY += 10;

        sd.history.forEach((log, index) => {
          if (curY > 250) return;
          doc.setFillColor(248, 250, 252);
          doc.rect(15, curY, 180, 8, 'F');
          
          doc.setDrawColor(241, 245, 249);
          doc.rect(15, curY, 180, 8, 'S');

          // Number bubble representation
          doc.setFillColor(224, 242, 254); // cyan bullet
          doc.rect(17, curY + 2, 4, 4, 'F');

          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(51, 65, 85); // Slate 700
          doc.text(`[Step #${index + 1}]  ${log}`, 25, curY + 5);

          curY += 9;
        });

        if (sd.history.length === 0) {
          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(8.5);
          doc.text("Pristine spectral waveform raw data loaded. No preprocessing log historical records found.", 20, curY + 5);
        }

        addFooter(3, totalPages);

        // -----------------------------------------
        // SAVE & TOAST TRIGGER
        // -----------------------------------------
        const filename = `${sd.name}_scientific_provenance_report.pdf`;
        const pdfOutputBlob = doc.output('blob');
        const url = URL.createObjectURL(pdfOutputBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        setExportStates(prev => ({ ...prev, pdf: 'success' }));

        triggerToast(
          "Academic PDF Report Generated",
          "Engineered a polished, multi-page scientific appendix complete with spectral plots, mathematical metadata, and peak assignments.",
          filename,
          () => {
            const reLink = document.createElement('a');
            reLink.href = url;
            reLink.download = filename;
            document.body.appendChild(reLink);
            reLink.click();
            document.body.removeChild(reLink);
          }
        );

        setTimeout(() => {
          setExportStates(prev => ({ ...prev, pdf: 'idle' }));
        }, 3000);

      } catch (err: any) {
        setExportStates(prev => ({ ...prev, pdf: 'idle' }));
        alert("Failed to export PDF: " + (err.message || err));
      }
    }, 1100); // realistic render timeline
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 text-gray-200">
      
      {/* Undo/Redo States Row */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#27272a]">
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleUndo}
            disabled={sd.undoStack.length <= 1}
            title="Undo"
            className="p-1 px-2 rounded bg-[#27272a] border border-[#3f3f46] disabled:opacity-30 disabled:hover:bg-[#27272a] hover:bg-[#3f3f46] hover:text-white text-zinc-300 transition-colors"
          >
            <Undo size={14} />
          </button>
          <button
            onClick={handleRedo}
            disabled={sd.redoStack.length === 0}
            title="Redo"
            className="p-1 px-2 rounded bg-[#27272a] border border-[#3f3f46] disabled:opacity-30 disabled:hover:bg-[#27272a] hover:bg-[#3f3f46] hover:text-white text-zinc-300 transition-colors"
          >
            <Redo size={14} />
          </button>
        </div>

        <button
          onClick={handleResetToRaw}
          className="flex items-center gap-1 text-[10px] text-rose-400 font-semibold uppercase tracking-wider bg-rose-500/10 hover:bg-rose-500/20 px-2 py-1 rounded transition"
        >
          <RefreshCw size={11} /> Reset Raw
        </button>
      </div>

      {/* Target Spec Calibration Dropdown */}
      <div className="bg-[#09090b] border border-[#27272a] rounded-lg p-3 mb-5 flex flex-col gap-2.5">
        <div className="flex items-center justify-between border-b border-[#27272a] pb-1.5">
          <span className="text-xxs font-bold uppercase text-teal-400 tracking-wider">Calibration & Technique</span>
          <span className="text-[9px] text-zinc-500 font-mono">ID: {sd.id.split('-').slice(0, 2).join('-')}</span>
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label className="block text-[9px] text-zinc-400 uppercase font-medium mb-1">Focus Spectrum Name</label>
            <input
              type="text"
              value={sd.name}
              onChange={(e) => {
                const val = e.target.value;
                const list = datasets.map(d => d.id === sd.id ? { ...d, name: val } : d);
                onDatasetsUpdated(list);
                onDatasetSelected(list.find(d => d.id === sd.id)!);
              }}
              className="w-full bg-[#18181b] border border-[#27272a] rounded px-2 py-1 text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500 font-medium"
            />
          </div>
          <div>
            <label className="block text-[9px] text-zinc-400 uppercase font-medium mb-1">Spectrometer Model</label>
            <select
              value={sd.technique}
              onChange={(e) => handleChangeTechnique(e.target.value)}
              className="w-full bg-[#18181b] border border-[#27272a] rounded px-2 py-1 text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500 font-medium"
            >
              <option value="UV-Vis Spectroscopy">UV-Vis Spectroscopy</option>
              <option value="FTIR Spectroscopy">FTIR Spectroscopy</option>
              <option value="Raman Spectroscopy">Raman Spectroscopy</option>
              <option value="1H NMR Spectroscopy">1H NMR Spectroscopy</option>
              <option value="13C NMR Spectroscopy">13C NMR Spectroscopy</option>
              <option value="2D COSY NMR Spectroscopy">2D COSY NMR Spectroscopy</option>
              <option value="XPS (X-ray Photoelectron Spectroscopy)">XPS (X-ray Photoelectron Spectroscopy)</option>
              <option value="Photoluminescence (PL) Spectroscopy">Photoluminescence (PL) Spectroscopy</option>
              <option value="XRD (X-ray Diffraction)">XRD (X-ray Diffraction)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tabs list representation */}
      <div className="flex border-b border-[#27272a] mb-5 gap-1 select-none font-sans overflow-x-auto scrollbar-none">
        {(['process', 'batch', 'analyze', 'tauc', 'jobs', 'style', 'export'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            className={`flex-1 text-center font-medium py-2 px-1 text-xs border-b-2 capitalize transition-all whitespace-nowrap min-w-[72px] cursor-pointer select-none ${
              activeTab === t
                ? 'border-teal-500 text-teal-400 bg-teal-500/5 font-semibold'
                : 'border-transparent text-gray-400 hover:text-gray-200 hover:bg-zinc-800'
            }`}
          >
            {t === 'jobs' ? "Job's Plot" : t === 'tauc' ? "Tauc Plot" : t}
          </button>
        ))}
      </div>

      {/* TAB CONTENTS */}
      <div className="flex flex-col gap-4 text-xs font-normal text-gray-300">
        
        {/* ==========================================
            TAB 1: PROCESS
            ========================================== */}
        {activeTab === 'process' && (
          <motion.div
            key="tab-process"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >
            
            {/* Blank subtraction */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a]">
              <label className="block text-xxs font-semibold uppercase text-zinc-400 mb-1">Subtract Reference Solvent</label>
              <select
                value={subtractionTarget}
                onChange={(e) => setSubtractionTarget(e.target.value)}
                className="w-full bg-[#18181b] border border-[#27272a] rounded px-2 py-1 text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
              >
                <option value="None">None</option>
                {datasets.filter(d => d.id !== sd.id).map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            {/* Smoothing and derivatives */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xxs font-semibold uppercase text-zinc-400">Smoothing Filter</span>
                <input
                  type="checkbox"
                  checked={smoothOpts.enabled}
                  onChange={(e) => setSmoothOpts({ ...smoothOpts, enabled: e.target.checked })}
                  className="rounded bg-zinc-800 accent-teal-500"
                />
              </div>

              {smoothOpts.enabled && (
                <div className="flex flex-col gap-2 mt-1">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[10px] text-gray-500 block mb-0.5">Algorithm</span>
                      <select
                        value={smoothOpts.method}
                        onChange={(e) => setSmoothOpts({ ...smoothOpts, method: e.target.value })}
                        className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white"
                      >
                        <option value="Savitzky-Golay">Savitzky-Golay</option>
                        <option value="Moving Average">Moving Average</option>
                      </select>
                    </div>

                    <div>
                      <span className="text-[10px] text-gray-500 block mb-0.5">Window Points</span>
                      <input
                        type="number"
                        value={smoothOpts.window}
                        step={2}
                        onChange={(e) => setSmoothOpts({ ...smoothOpts, window: Math.max(3, parseInt(e.target.value) || 3) })}
                        className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white text-center focus:outline-none"
                      />
                    </div>
                  </div>

                  {smoothOpts.method === 'Savitzky-Golay' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] text-gray-500 block mb-0.5">Polynomial Order</span>
                        <input
                          type="number"
                          value={smoothOpts.poly}
                          min={1}
                          max={5}
                          onChange={(e) => setSmoothOpts({ ...smoothOpts, poly: Math.max(1, parseInt(e.target.value) || 1) })}
                          className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white text-center focus:outline-none"
                        />
                      </div>

                      <div>
                        <span className="text-[10px] text-gray-500 block mb-0.5">Derivative calculus</span>
                        <select
                          value={smoothOpts.deriv}
                          onChange={(e) => setSmoothOpts({ ...smoothOpts, deriv: parseInt(e.target.value) })}
                          className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white"
                        >
                          <option value="0">0 (Smoothed)</option>
                          <option value="1">1st Derivative</option>
                          <option value="2">2nd Derivative</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Baseline subtractor options */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2">
              <label className="block text-xxs font-semibold uppercase text-zinc-400">Baseline backdrop removal</label>
              <select
                value={baselineMethod}
                onChange={(e) => {
                  const val = e.target.value as any;
                  if (!isPremium && (val === 'ALS' || val === 'Shirley')) {
                    onTriggerUpgrade();
                  } else {
                    setBaselineMethod(val);
                  }
                }}
                className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs text-white"
              >
                <option value="None">None</option>
                <option value="ALS">ALS (Raman/FTIR baseline) {!isPremium && "🔒 Pro"}</option>
                <option value="SNIP">SNIP background subtraction (Free)</option>
                <option value="Shirley">Shirley background (XPS spectra) {!isPremium && "🔒 Pro"}</option>
              </select>

              {baselineMethod === 'ALS' && (
                <div className="mt-2 flex flex-col gap-2 p-2.5 rounded bg-[#121214] border border-[#27272a]">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-zinc-450 font-semibold uppercase">Correction Strength</span>
                    <span className="text-[10px] font-mono text-teal-400 font-bold bg-teal-950/40 border border-teal-500/25 rounded px-1.5 py-0.5 animate-pulse">
                      {Math.max(0, Math.min(100, Math.round((8 - Math.log10(alsLam)) / 6 * 100)))}%
                    </span>
                  </div>
                  
                  {/* Real-time slider */}
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={Math.max(0, Math.min(100, Math.round((8 - Math.log10(alsLam)) / 6 * 100)))}
                    onChange={(e) => {
                      const pct = Number(e.target.value);
                      const newLam = Math.pow(10, 8 - (pct / 100) * 6);
                      setAlsLam(newLam);
                    }}
                    className="w-full h-1 bg-zinc-800 accent-teal-500 rounded-lg appearance-none cursor-pointer focus:outline-none"
                  />

                  <div className="flex items-center justify-between text-[9px] text-zinc-500 font-medium">
                    <span>Rigid Baseline (Low)</span>
                    <span>Adaptive Baseline (High)</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 items-center mt-1.5 pt-1.5 border-t border-[#1f1f23]">
                    <span className="col-span-2 text-[9px] text-zinc-400 font-mono">Lambda (λ penalty):</span>
                    <input
                      type="number"
                      value={Math.round(alsLam)}
                      step={100}
                      onChange={(e) => setAlsLam(Math.max(1, Number(e.target.value) || 1))}
                      className="bg-[#18181b] border border-[#27272a] rounded p-1 text-[10px] text-white text-center font-mono focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Custom standard check norm options */}
            <div className="flex items-center justify-between p-3 rounded bg-[#09090b] border border-[#27272a]">
              <span className="text-xxs font-semibold uppercase text-zinc-400">Min/Max Normalization</span>
              <input
                type="checkbox"
                checked={normalizeY}
                onChange={(e) => setNormalizeY(e.target.checked)}
                className="accent-teal-500 rounded"
              />
            </div>

            {/* master action submit */}
            <button
              onClick={handleApplyProcess}
              className="w-full flex items-center justify-center gap-1.5 bg-teal-600 hover:bg-teal-500 text-white font-semibold py-2 px-4 rounded border border-teal-500/20 shadow-md transition-all uppercase text-[10px] tracking-wider mt-2 cursor-pointer"
            >
              <Sliders size={13} /> Compute Trace pipeline
            </button>
          </motion.div>
        )}

        {/* ==========================================
            TAB: BATCH PROCESSOR (DEDICATED PANEL)
            ========================================== */}
        {activeTab === 'batch' && (
          <motion.div
            key="tab-batch"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >
            <div className="bg-[#0c0c0e] p-3.5 rounded-lg border border-teal-500/20 shadow-md">
              
              {/* Section Title */}
              <div className="flex items-center gap-1.5 mb-3">
                <Layers size={13} className="text-teal-400" />
                <span className="text-xxs font-bold uppercase tracking-wider text-teal-400 font-mono">Batch Operations Control</span>
              </div>
              
              <p className="text-[10px] text-zinc-400 leading-relaxed mb-3">
                Apply identical baseline filters, smoothing parameters, or scale normalizations to multiple spectral coordinates at once.
              </p>

              {/* 1. Dataset checklist */}
              <div className="flex flex-col gap-1.5 mb-4">
                <div className="flex items-center justify-between text-[10px] uppercase font-bold text-zinc-400">
                  <span>1. Target Datasets ({batchSelectedIds.length})</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setBatchSelectedIds(datasets.map(d => d.id))}
                      className="text-teal-400 hover:text-teal-300 font-semibold lowercase cursor-pointer"
                    >
                      all
                    </button>
                    <span className="text-zinc-600">|</span>
                    <button
                      onClick={() => setBatchSelectedIds([])}
                      className="text-teal-400 hover:text-teal-300 font-semibold lowercase cursor-pointer"
                    >
                      none
                    </button>
                  </div>
                </div>

                <div className="max-h-32 overflow-y-auto border border-[#27272a] rounded bg-[#121214] p-1.5 flex flex-col gap-1 scrollbar-thin">
                  {datasets.map(d => {
                    const isChecked = batchSelectedIds.includes(d.id);
                    const isCurrentActive = d.id === sd.id;
                    return (
                      <label
                        key={d.id}
                        className={`flex items-center justify-between p-1 px-1.5 rounded text-[11px] cursor-pointer hover:bg-[#1f1f23] transition-colors select-none ${
                          isChecked ? 'text-zinc-100 font-medium' : 'text-zinc-400'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate flex-1 mr-2">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setBatchSelectedIds(prev => [...prev, d.id]);
                              } else {
                                setBatchSelectedIds(prev => prev.filter(id => id !== d.id));
                              }
                            }}
                            className="accent-teal-500 rounded bg-zinc-800 cursor-pointer"
                          />
                          <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                          <span className="truncate">{d.name}</span>
                        </div>
                        {isCurrentActive && (
                          <span className="text-[8px] uppercase px-1 py-0.2 rounded font-mono font-bold bg-teal-950 text-teal-400 border border-teal-500/25 shrink-0 select-none">
                            Active
                          </span>
                        )}
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* 2. Operations Selector */}
              <div className="space-y-3 border-t border-[#27272a]/80 pt-3.5 mb-3.5">
                <span className="block text-[10px] uppercase font-bold text-zinc-400">2. Active Workflows</span>
                
                {/* Source selection */}
                <div className="flex items-center justify-between p-1.5 px-2 rounded bg-[#121214] border border-[#27272a]/40">
                  <span className="text-[10px] font-medium text-zinc-300">Compute starting from:</span>
                  <select
                    value={batchFromRaw ? "raw" : "processed"}
                    onChange={(e) => setBatchFromRaw(e.target.value === "raw")}
                    className="bg-[#18181b] border border-[#27272a] rounded text-[10.5px] p-1 px-1 text-zinc-200 cursor-pointer text-center"
                  >
                    <option value="raw">Original (y_orig)</option>
                    <option value="processed">Processed (y_processed)</option>
                  </select>
                </div>

                {/* Batch Smoothing */}
                <div className="bg-[#121214] p-2 rounded border border-[#27272a]/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10.5px] font-semibold text-zinc-300">Smoothing Filter</span>
                    <input
                      type="checkbox"
                      checked={batchSmoothEnabled}
                      onChange={(e) => setBatchSmoothEnabled(e.target.checked)}
                      className="rounded accent-teal-500 cursor-pointer"
                    />
                  </div>
                  {batchSmoothEnabled && (
                    <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-[#27272a]/20">
                      <div>
                        <span className="text-[9px] text-zinc-500 block">Algorithm</span>
                        <select
                          value={batchSmoothMethod}
                          onChange={(e) => setBatchSmoothMethod(e.target.value as any)}
                          className="w-full bg-[#18181b] border border-[#27272a] rounded p-0.5 text-[10px] text-white"
                        >
                          <option value="Savitzky-Golay">Savitzky-Golay</option>
                          <option value="Moving Average">Moving Average</option>
                        </select>
                      </div>
                      <div>
                        <span className="text-[9px] text-zinc-500 block">Window Size</span>
                        <input
                          type="number"
                          value={batchSmoothWindow}
                          step={2}
                          onChange={(e) => setBatchSmoothWindow(Math.max(3, parseInt(e.target.value) || 3))}
                          className="w-full bg-[#18181b] border border-[#27272a] rounded p-0.5 text-[10px] text-white text-center focus:outline-none"
                        />
                      </div>
                      {batchSmoothMethod === 'Savitzky-Golay' && (
                        <>
                          <div>
                            <span className="text-[9px] text-zinc-500 block">Polynomial Order</span>
                            <input
                              type="number"
                              value={batchSmoothPoly}
                              min={1}
                              max={5}
                              onChange={(e) => setBatchSmoothPoly(Math.max(1, parseInt(e.target.value) || 1))}
                              className="w-full bg-[#18181b] border border-[#27272a] rounded p-0.5 text-[10px] text-white text-center focus:outline-none"
                            />
                          </div>
                          <div>
                            <span className="text-[9px] text-zinc-500 block">Derivative</span>
                            <select
                              value={batchSmoothDeriv}
                              onChange={(e) => setBatchSmoothDeriv(parseInt(e.target.value) || 0)}
                              className="w-full bg-[#18181b] border border-[#27272a] rounded p-0.5 text-[10px] text-white"
                            >
                              <option value="0">0 (Smoothed)</option>
                              <option value="1">1st Deriv</option>
                              <option value="2">2nd Deriv</option>
                            </select>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* Batch Baseline Subtraction */}
                <div className="bg-[#121214] p-2 rounded border border-[#27272a]/40 space-y-2">
                  <div>
                    <span className="text-[10.5px] font-semibold text-zinc-300 block mb-1">Baseline Removal</span>
                    <select
                      value={batchBaselineMethod}
                      onChange={(e) => {
                        const val = e.target.value as any;
                        if (!isPremium && (val === 'ALS' || val === 'Shirley')) {
                          onTriggerUpgrade();
                        } else {
                          setBatchBaselineMethod(val);
                        }
                      }}
                      className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white cursor-pointer"
                    >
                      <option value="None">None</option>
                      <option value="ALS">ALS (FTIR/Raman) {!isPremium && "🔒 Pro"}</option>
                      <option value="SNIP">SNIP background subtraction</option>
                      <option value="Shirley">Shirley background (XPS) {!isPremium && "🔒 Pro"}</option>
                    </select>
                  </div>
                  {batchBaselineMethod === 'ALS' && (
                    <div className="pt-1 border-t border-[#27272a]/20">
                      <span className="text-[9px] text-zinc-500 block">ALS lambda (λ penalty)</span>
                      <input
                        type="number"
                        value={batchAlsLam}
                        step={100}
                        onChange={(e) => setBatchAlsLam(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full bg-[#18181b] border border-[#27272a] rounded p-0.5 text-[10px] text-center focus:outline-none text-white"
                      />
                    </div>
                  )}
                </div>

                {/* Batch Normalization */}
                <div className="flex items-center justify-between p-2 rounded bg-[#121214] border border-[#27272a]/40">
                  <span className="text-[10.5px] font-semibold text-zinc-300">Min/Max Normalization (0.0 - 1.0 scale)</span>
                  <input
                    type="checkbox"
                    checked={batchNormalizeY}
                    onChange={(e) => setBatchNormalizeY(e.target.checked)}
                    className="accent-teal-500 rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Submit button */}
              <button
                onClick={handleApplyBatchProcess}
                className="w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold py-2.5 px-4 rounded border border-teal-500/20 shadow transition-all uppercase text-[10px] tracking-wider font-mono cursor-pointer select-none"
              >
                <Layers size={13} className="stroke-[2.5]" /> Apply Batch Workflows
              </button>
            </div>
          </motion.div>
        )}

        {/* ==========================================
            TAB: TAUC SEMICONDUCTOR BANDGAP ANALYSIS
            ========================================== */}
        {activeTab === 'tauc' && (
          <motion.div
            key="tab-tauc"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >
            <div className="bg-[#09090b] p-3.5 rounded-lg border border-teal-500/20 shadow-md">
              <div className="flex items-center gap-1.5 mb-2.5">
                <Sparkles size={13} className="text-orange-400 animate-pulse" />
                <span className="text-xxs font-bold uppercase tracking-wider text-orange-400">Tauc Bandgap Estimator</span>
              </div>
              <p className="text-[10.5px] text-zinc-400 leading-relaxed mb-3">
                Calculate the optical bandedge (Eg) of material coatings or nanoparticles using the {"(Ahν)^(1/n)"} vs hv intercept technique.
              </p>

              {/* Toggle switcher card */}
              <div className="flex items-center justify-between p-2.5 rounded bg-[#121214] border border-[#27272a] mb-3">
                <div>
                  <span className="text-[11px] font-bold text-zinc-200 block">Tauc Analysis Mode</span>
                  <span className="text-[9.5px] text-zinc-500 block">Convert to photon energy ($h\nu$)</span>
                </div>
                <button
                  onClick={() => {
                    if (sd.isTauc) {
                      handleDisableTaucPlot();
                    } else {
                      handleTaucTransformation('direct');
                    }
                  }}
                  className={`relative inline-flex h-5.5 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    sd.isTauc ? 'bg-orange-500' : 'bg-zinc-700'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      sd.isTauc ? 'translate-x-5.5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Option details */}
              {sd.isTauc && sd.taucData ? (
                <div className="flex flex-col gap-3">
                  <div className="bg-[#121214] p-3 rounded border border-[#27272a] flex flex-col gap-2">
                    <span className="text-[10px] uppercase font-bold text-zinc-400">Optical Transition Profile</span>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <button
                        onClick={() => handleTaucTransformation('direct')}
                        className={`py-1.5 px-2 rounded border font-semibold text-xxs transition ${
                          sd.taucData.transition === 'direct'
                            ? 'bg-orange-500/10 border-orange-500 text-orange-400 font-bold shadow'
                            : 'bg-[#18181b] border-[#27272a] hover:bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        Direct ($n=1/2$)
                      </button>
                      <button
                        onClick={() => handleTaucTransformation('indirect')}
                        className={`py-1.5 px-2 rounded border font-semibold text-xxs transition ${
                          sd.taucData.transition === 'indirect'
                            ? 'bg-orange-500/10 border-orange-400 text-orange-400 font-bold shadow'
                            : 'bg-[#18181b] border-[#27272a] hover:bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        Indirect ($n=2$)
                      </button>
                    </div>
                    <span className="text-[9.5px] text-zinc-500 leading-normal mt-1 leading-relaxed">
                      {sd.taucData.transition === 'direct' 
                        ? "Evaluated using (α·hν)² vs photon energy, typical for standard direct-band semiconductors." 
                        : "Evaluated using (α·hν)⁰⁵ vs photon energy, typical for indirect transition lattices."}
                    </span>
                  </div>

                  {/* Results values */}
                  <div className="bg-orange-950/15 border border-orange-500/20 rounded-lg p-3 flex flex-col gap-2">
                    <div className="flex items-center gap-1.5 border-b border-orange-500/10 pb-1.5">
                      <span className="text-[10px] font-bold uppercase text-orange-400 tracking-wider">Bandgap Estimate (Eg)</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-[#0c0a0b] p-2 rounded border border-orange-950/40">
                        <span className="text-zinc-500 block text-[9px] mb-0.5">Eg Intercept</span>
                        <span className="text-sm font-mono font-bold text-orange-400">{sd.taucData.eg.toFixed(3)} eV</span>
                      </div>
                      <div className="bg-[#0c0a0b] p-2 rounded border border-orange-950/40">
                        <span className="text-zinc-500 block text-[9px] mb-0.5">Wavelength Equiv.</span>
                        <span className="text-sm font-mono font-bold text-zinc-300">{(1240 / sd.taucData.eg).toFixed(1)} nm</span>
                      </div>
                    </div>

                    <div className="p-2 rounded bg-[#0e0708] border border-orange-950/30 font-mono text-[9.5px] text-zinc-400 leading-relaxed">
                      <span className="font-semibold block text-zinc-300 text-[9px] font-sans uppercase mb-0.5">Regression Formula</span>
                      y = {sd.taucData.m.toExponential(2)} * x + {sd.taucData.c.toExponential(2)}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-[#121214]/60 border border-zinc-800 rounded text-center text-zinc-500 text-xxs leading-relaxed italic">
                  Select a candidate semiconductor spectral trace and toggle Tauc plot mode above to auto-extrapolate the semiconductor bandgap limits.
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* ==========================================
            TAB: JOB'S METHOD STOICHIOMETRY ANALYSIS
            ========================================== */}
        {activeTab === 'jobs' && (
          <motion.div
            key="tab-jobs"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >
            <div className="bg-[#09090b] p-3.5 rounded-lg border border-teal-500/20 shadow-md">
              <div className="flex items-center gap-1.5 mb-2.5">
                <Sparkles size={13} className="text-rose-400" />
                <span className="text-xxs font-bold uppercase tracking-wider text-rose-400">Job's Method (Continuous Variation)</span>
              </div>
              <p className="text-[10.5px] text-zinc-400 leading-relaxed mb-3">
                Determine the stoichiometric binding ratios of complex chemical mixtures by plotting absorbance deviation against mole fractions.
              </p>

              {/* Step 1: Select continuous variation datasets */}
              <div className="flex flex-col gap-1.5 mb-3.5">
                <div className="flex items-center justify-between text-[10px] uppercase font-bold text-zinc-400">
                  <span>1. Mixture Series Datasets ({jobsSelectedIds.length})</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const candidates = datasets.filter(d => d.technique !== "Job's Plot").map(d => d.id);
                        setJobsSelectedIds(candidates);
                      }}
                      className="text-teal-400 hover:text-teal-300 font-semibold lowercase cursor-pointer"
                    >
                      all
                    </button>
                    <span className="text-zinc-600">|</span>
                    <button
                      onClick={() => setJobsSelectedIds([])}
                      className="text-[#e11d48] hover:text-rose-400 font-semibold lowercase cursor-pointer"
                    >
                      none
                    </button>
                  </div>
                </div>

                <div className="max-h-32 overflow-y-auto border border-[#27272a] rounded bg-[#121214] p-1.5 flex flex-col gap-1 scrollbar-thin">
                  {datasets.filter(d => d.technique !== "Job's Plot").map((d, index, arr) => {
                    const isChecked = jobsSelectedIds.includes(d.id);
                    return (
                      <div
                        key={d.id}
                        className={`flex items-center justify-between p-1 px-1.5 rounded text-[11px] hover:bg-[#1f1f23] transition-colors select-none ${
                          isChecked ? 'text-zinc-100 font-medium bg-zinc-900/50' : 'text-zinc-400'
                        }`}
                      >
                        <label className="flex items-center gap-2 truncate cursor-pointer flex-1">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setJobsSelectedIds(prev => [...prev, d.id]);
                              } else {
                                setJobsSelectedIds(prev => prev.filter(id => id !== d.id));
                              }
                            }}
                            className="accent-rose-500 rounded bg-zinc-800 cursor-pointer"
                          />
                          <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                          <span className="truncate">{d.name}</span>
                        </label>
                        <div className="flex items-center gap-1 shrink-0 ml-2">
                          <span className="text-[9px] text-zinc-500 font-mono">X_G:</span>
                          <input
                            type="number"
                            min={0}
                            max={1}
                            step={0.05}
                            value={customMoleFractions[d.id] ?? (isChecked && jobsSelectedIds.indexOf(d.id) >= 0 && jobsSelectedIds.length > 1 ? Number((jobsSelectedIds.indexOf(d.id) / (jobsSelectedIds.length - 1)).toFixed(3)) : 0)}
                            onChange={(e) => {
                              const v = Math.max(0, Math.min(1, parseFloat(e.target.value) || 0));
                              setCustomMoleFractions(prev => ({ ...prev, [d.id]: v }));
                            }}
                            disabled={!isChecked}
                            className="w-10 bg-[#18181b] border border-[#27272a] text-[9px] text-center font-mono rounded text-zinc-300 disabled:opacity-40 disabled:pointer-events-none p-0.5 focus:outline-none focus:border-teal-500"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <span className="text-[9px] text-zinc-500 italic mt-0.5">
                  Rearrange order of selection or edit the guest mole fraction percentage (X_G) manually.
                </span>
              </div>

              {/* Step 2: Choose target coordinate wavelength */}
              <div className="bg-[#121214] p-2.5 rounded border border-[#27272a]/60 flex flex-col gap-2 mb-3.5">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-bold uppercase text-zinc-400">2. Analysis Coordinate</span>
                  <button
                    onClick={() => {
                      if (sd && sd.peaks && sd.peaks.length > 0) {
                        setJobsTargetWl(sd.peaks[0].x.toString());
                      } else {
                        let maxIdx = 0;
                        let maxVal = -Infinity;
                        for (let i = 0; i < sd.y_processed.length; i++) {
                          if (sd.y_processed[i] > maxVal) {
                            maxVal = sd.y_processed[i];
                            maxIdx = i;
                          }
                        }
                        if (sd.x[maxIdx]) {
                          setJobsTargetWl(sd.x[maxIdx].toFixed(0));
                        }
                      }
                    }}
                    className="text-[9px] text-rose-400 hover:text-rose-300 cursor-pointer underline hover:no-underline font-mono"
                  >
                    Auto-detect Peak Max
                  </button>
                </div>
                <div className="grid grid-cols-3 gap-2 items-center">
                  <span className="text-[10px] text-zinc-400">Wavelength (nm):</span>
                  <input
                    type="number"
                    value={jobsTargetWl}
                    onChange={(e) => setJobsTargetWl(e.target.value)}
                    className="col-span-2 bg-[#18181b] border border-[#27272a] rounded p-1 text-center font-mono text-xs text-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                  />
                </div>
              </div>

              {/* Step 3: Run analysis */}
              <button
                onClick={() => handleApplyJobsMethod()}
                className="w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold py-2 px-3 rounded border border-rose-500/20 shadow-lg transition-all uppercase text-[10px] tracking-wider font-mono cursor-pointer select-none"
              >
                <Sparkles size={11} className="stroke-[2.5]" /> Run Stoichiometry Solver
              </button>
            </div>

            {/* Smart Stoichiometric Advisor HUD */}
            {sd.technique === "Job's Plot" && sd.jobsData && (
              <div className="bg-rose-950/25 border border-rose-500/30 rounded-lg p-3.5 flex flex-col gap-2.5">
                <div className="flex items-center gap-1.5 border-b border-rose-500/20 pb-1.5">
                  <span className="text-xxs font-bold uppercase text-rose-400 tracking-wider">Stoichiometry Solver Results</span>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-xxs">
                  <div className="bg-[#0e0a0d] p-2 rounded border border-rose-950">
                    <span className="text-zinc-500 block mb-0.5">Intercept X_max</span>
                    <span className="text-sm font-mono font-bold text-rose-400">{sd.jobsData.x_int.toFixed(3)}</span>
                  </div>
                  <div className="bg-[#0e0a0d] p-2 rounded border border-rose-950">
                    <span className="text-zinc-500 block mb-0.5">Predicted Stoichiometry</span>
                    <span className="text-sm font-bold text-teal-400">{getStoichiometryName(sd.jobsData.x_int).ratio} {getStoichiometryName(sd.jobsData.x_int).formula}</span>
                  </div>
                </div>

                <div className="p-2 sm:p-2.5 rounded bg-[#10070a] border border-rose-950/30">
                  <span className="text-[10px] font-semibold text-zinc-300 block mb-0.5">Binding Description</span>
                  <p className="text-[9.5px] leading-relaxed text-zinc-400">{getStoichiometryName(sd.jobsData.x_int).desc}</p>
                </div>

                <div className="flex items-center justify-between text-[9px] text-zinc-500 font-mono pt-1">
                  <span>Regression Left R²: {(sd.jobsData.r2_1 || 0.992).toFixed(4)}</span>
                  <span>Regression Right R²: {(sd.jobsData.r2_2 || 0.989).toFixed(4)}</span>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* ==========================================
            TAB 2: ANALYZE & DECONVOLUTION
            ========================================== */}
        {activeTab === 'analyze' && (
          <motion.div
            key="tab-analyze"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >
            
            {/* Interactive modes selects */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a]">
              <span className="block text-xxs font-semibold uppercase text-teal-400 mb-2">Interactive Canvas Tool</span>
              <div className="grid grid-cols-2 gap-1.5 select-none">
                {(['navigate', 'pick', 'crop', 'integrate'] as const).map(mode => (
                  <button
                    key={mode}
                    onClick={() => setInteractiveMode(mode)}
                    className={`py-1.5 px-1.5 rounded border capitalize text-xxs font-medium transition ${
                      interactiveMode === mode
                        ? 'bg-teal-500/10 border-teal-500 text-teal-400'
                        : 'bg-[#18181b] border-[#27272a] hover:bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Peak auto search */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">Peak Detection threshold (SciPy equivalent)</span>
              <div className="flex gap-2">
                <input
                  type="number"
                  step={0.01}
                  value={peakProminence}
                  onChange={(e) => setPeakProminence(Math.max(0.001, Number(e.target.value) || 0.01))}
                  className="flex-1 bg-[#18181b] border border-[#27272a] rounded p-1 text-center focus:outline-none"
                  placeholder="prominence threshold"
                />
                <button
                  onClick={handleAutoPickPeaks}
                  className="bg-[#27272a] hover:bg-zinc-800 border border-[#3f3f46] text-xxs px-3 py-1 rounded text-teal-400 font-semibold"
                >
                  Scan Picks
                </button>
              </div>
              
              <button
                onClick={handleMnovaExpertSystems}
                className="w-full mt-1 flex items-center justify-center gap-1.5 bg-[#27272a] hover:bg-[#3f3f46] border border-[#3f3f46] text-white py-1.5 px-3 rounded text-xxs font-semibold transition"
              >
                <Sparkles size={11} className="text-teal-400 animate-pulse" /> Interpret with Mnova Expert
              </button>
            </div>

            {/* Peak fitting profile */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-3">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">LM Equivalently Bounded Deconvolution</span>
              
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">Peak Model</span>
                  <select
                    value={fitProfile}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      if (!isPremium && val === 'Voigt') {
                        onTriggerUpgrade();
                      } else {
                        setFitProfile(val);
                      }
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white"
                  >
                    <option value="Gaussian">Gaussian Model (Free)</option>
                    <option value="Lorentzian">Lorentzian Model (Free)</option>
                    <option value="Voigt">Voigt Blend Profile {!isPremium && "🔒 Pro"}</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-1 pt-4">
                  <span className="text-[10px] text-gray-400">Enforce bounds</span>
                  <input
                    type="checkbox"
                    checked={fitConstraints.enforce}
                    onChange={(e) => setFitConstraints({ ...fitConstraints, enforce: e.target.checked })}
                    className="accent-teal-500 rounded"
                  />
                </div>
              </div>

              {fitConstraints.enforce && (
                <div className="grid grid-cols-3 gap-2 border-t border-[#1e1e24] pt-2 mt-1">
                  <div>
                    <span className="text-[9px] text-zinc-500 block">Center Tol</span>
                    <input
                      type="number"
                      value={fitConstraints.centerTol}
                      onChange={(e) => setFitConstraints({ ...fitConstraints, centerTol: Math.abs(Number(e.target.value)) })}
                      className="w-full bg-[#18181b] border border-[#27272a] p-1 text-[10px] text-center"
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-zinc-500 block">Min Width</span>
                    <input
                      type="number"
                      value={fitConstraints.widthMin}
                      onChange={(e) => setFitConstraints({ ...fitConstraints, widthMin: Math.abs(Number(e.target.value)) })}
                      className="w-full bg-[#18181b] border border-[#27272a] p-1 text-[10px] text-center"
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-zinc-500 block">Max Width</span>
                    <input
                      type="number"
                      value={fitConstraints.widthMax}
                      onChange={(e) => setFitConstraints({ ...fitConstraints, widthMax: Math.abs(Number(e.target.value)) })}
                      className="w-full bg-[#18181b] border border-[#27272a] p-1 text-[10px] text-center"
                    />
                  </div>
                </div>
              )}

              <button
                onClick={handleRunCurveDeconvolution}
                className="w-full bg-teal-600 hover:bg-teal-500 text-white font-semibold py-1.5 px-3 rounded text-[10px] uppercase tracking-wider transition"
              >
                Run curve fit optimizer
              </button>
            </div>

            {/* Solid State Stoichiometry */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">Solid-State physics & continuous variations</span>
              <div className="grid grid-cols-2 gap-2 select-none">
                <button
                  onClick={() => handleTaucTransformation('direct')}
                  className="bg-[#27272a] hover:bg-[#3f3f46] border border-[#3f3f46] text-white py-2 px-2 rounded font-semibold text-xxs transition"
                >
                  Direct Tauc Eg
                </button>
                <button
                  onClick={() => handleTaucTransformation('indirect')}
                  className="bg-[#27272a] hover:bg-[#3f3f46] border border-[#3f3f46] text-white py-2 px-2 rounded font-semibold text-xxs transition"
                >
                  Indirect Tauc Eg
                </button>
              </div>

              <button
                onClick={handleCreateJobsPlot}
                className="w-full mt-1 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/20 text-rose-300 py-1.5 px-3 rounded font-semibold text-xxs transition"
              >
                Calculate stoichiometric Job's plot
              </button>
            </div>

          </motion.div>
        )}

        {/* ==========================================
            TAB 3: STYLE & PRESENTATION
            ========================================== */}
        {activeTab === 'style' && (
          <motion.div
            key="tab-style"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >

            {/* Primary Manual Absorbance Limits Override Controller */}
            <div className="bg-gradient-to-br from-teal-950/25 to-[#09090b] p-3.5 rounded-lg border border-teal-500/30 flex flex-col gap-3 shadow-md">
              <div className="flex items-center justify-between border-b border-[#27272a] pb-2">
                <div className="flex items-center gap-1.5">
                  <Sliders size={13} className="text-teal-400" />
                  <span className="block text-xxs font-bold uppercase tracking-wider text-zinc-300">Absorbance Limits (Y-Axis)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-zinc-400 font-medium">Autoset Bounds</span>
                  <input
                    type="checkbox"
                    checked={autoY}
                    onChange={(e) => setAutoY(e.target.checked)}
                    className="w-4 h-4 text-teal-600 bg-zinc-800 border-zinc-700 rounded focus:ring-teal-500 focus:ring-offset-zinc-900 accent-teal-500 cursor-pointer"
                  />
                </div>
              </div>

              <p className="text-[10px] text-zinc-400 leading-normal">
                If high-intensity peaks or labels are truncated, disable autoset above and specify absolute Y-scale limits.
              </p>

              {!autoY ? (
                <div className="flex flex-col gap-2.5">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[9px] text-zinc-400 uppercase font-mono mb-1">Min Abs (Y-Min)</label>
                      <input
                        type="number"
                        step="0.05"
                        value={manualYMin}
                        onChange={(e) => setManualYMin(parseFloat(e.target.value) || 0)}
                        className="w-full bg-[#18181b] border border-[#27272a] focus:border-teal-500 rounded p-1.5 text-xs text-center font-mono text-white"
                        placeholder="0.00"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] text-zinc-400 uppercase font-mono mb-1">Max Abs (Y-Max)</label>
                      <input
                        type="number"
                        step="0.05"
                        value={manualYMax}
                        onChange={(e) => setManualYMax(parseFloat(e.target.value) || 1)}
                        className="w-full bg-[#18181b] border border-[#27272a] focus:border-teal-500 rounded p-1.5 text-xs text-center font-mono text-white"
                        placeholder="1.20"
                      />
                    </div>
                  </div>

                  {/* Range presets for fast clicks */}
                  <div className="flex flex-col gap-1 mt-1 border-t border-[#1e1e24] pt-2">
                    <span className="text-[9px] text-zinc-500 font-semibold uppercase tracking-wider">Fast Presets</span>
                    <div className="grid grid-cols-3 gap-1">
                      {[
                        { label: '0.0 to 1.0', min: 0, max: 1.0 },
                        { label: '0.0 to 1.5', min: 0, max: 1.5 },
                        { label: '0.0 to 2.0', min: 0, max: 2.0 },
                        { label: '0.0 to 3.0', min: 0, max: 3.0 },
                        { label: '-0.1 to 1.2', min: -0.1, max: 1.2 },
                        { label: '-0.2 to 2.5', min: -0.2, max: 2.5 },
                      ].map((preset) => (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => {
                            setManualYMin(preset.min);
                            setManualYMax(preset.max);
                          }}
                          className="bg-[#18181b] hover:bg-[#27272a] border border-zinc-800 hover:border-zinc-700 rounded text-[9px] text-zinc-300 py-1 transition-all font-mono"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-[#18181b]/50 border border-zinc-800/60 rounded p-2 flex items-center justify-between text-[10px] text-zinc-400">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-teal-400 rounded-full animate-pulse" />
                    <span>Using Dynamic Absorbance Autoscaling</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setAutoY(false)}
                    className="text-teal-400 hover:text-teal-300 font-bold uppercase text-[9px] tracking-wider"
                  >
                    Set Manually
                  </button>
                </div>
              )}
            </div>

            {/* Swatch colour picker */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2.5">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">Trace aesthetics (Selected curve)</span>
              
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-gray-400">Curve Accent Color</span>
                <input
                  type="color"
                  value={sd.color}
                  onChange={(e) => {
                    const list = datasets.map(d => d.id === sd.id ? { ...d, color: e.target.value } : d);
                    onDatasetsUpdated(list);
                  }}
                  className="w-7 h-6 cursor-pointer bg-transparent border-0 rounded"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">Line style</span>
                  <select
                    value={sd.lineStyle}
                    onChange={(e) => {
                      const list = datasets.map(d => d.id === sd.id ? { ...d, lineStyle: e.target.value as any } : d);
                      onDatasetsUpdated(list);
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs"
                  >
                    <option value="solid">Solid Line</option>
                    <option value="dashed">Dashed (--)</option>
                    <option value="dotted">Dotted (:)</option>
                    <option value="none">Line Hide</option>
                  </select>
                </div>

                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">Line weights</span>
                  <input
                    type="number"
                    step={0.5}
                    min={0.5}
                    max={6}
                    value={sd.lineWidth}
                    onChange={(e) => {
                      const list = datasets.map(d => d.id === sd.id ? { ...d, lineWidth: Math.max(0.1, Number(e.target.value) || 1) } : d);
                      onDatasetsUpdated(list);
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs text-center"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">Markers</span>
                  <select
                    value={sd.marker}
                    onChange={(e) => {
                      const list = datasets.map(d => d.id === sd.id ? { ...d, marker: e.target.value as any } : d);
                      onDatasetsUpdated(list);
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs"
                  >
                    <option value="none">None</option>
                    <option value="circle">Circles (o)</option>
                    <option value="square">Squares (s)</option>
                    <option value="triangle">Triangles (^)</option>
                    <option value="cross">Crosses (x)</option>
                  </select>
                </div>

                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">Marker size</span>
                  <input
                    type="number"
                    value={sd.markerSize}
                    min={2}
                    max={15}
                    onChange={(e) => {
                      const list = datasets.map(d => d.id === sd.id ? { ...d, markerSize: Math.max(1, parseInt(e.target.value) || 5) } : d);
                      onDatasetsUpdated(list);
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs text-center"
                  />
                </div>
              </div>
            </div>

            {/* Plot Canvas Background Selector */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2.5">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">Spectrum Plot Background</span>
              <p className="text-[10px] text-zinc-500 leading-relaxed">
                Choose a dark or light presentation background. High-impact journals require light/white plots for publications.
              </p>
              
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => setPlotBgColor('#ffffff')}
                  className={`py-1 px-2 text-xxs rounded border font-semibold transition flex items-center justify-center gap-1.5 ${
                    plotBgColor.toLowerCase() === '#ffffff'
                      ? 'bg-white text-black border-zinc-200'
                      : 'bg-[#18181b] text-zinc-300 border-[#27272a] hover:border-[#3f3f46]'
                  }`}
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-white border border-zinc-300" />
                  Publication Light
                </button>
                <button
                  type="button"
                  onClick={() => setPlotBgColor('#131316')}
                  className={`py-1 px-1.5 text-xxs rounded border font-semibold transition flex items-center justify-center gap-1.5 ${
                    plotBgColor.toLowerCase() === '#131316'
                      ? 'bg-[#1c1c1f] text-white border-teal-500/50'
                      : 'bg-[#18181b] text-zinc-300 border-[#27272a] hover:border-[#3f3f46]'
                  }`}
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-[#131316] border border-zinc-750" />
                  Classic Dark
                </button>
              </div>

              <div className="flex items-center justify-between mt-1 pt-1 border-t border-[#1e1e24]">
                <span className="text-[11px] text-zinc-400">Custom Background</span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={plotBgColor}
                    onChange={(e) => setPlotBgColor(e.target.value)}
                    className="w-16 bg-[#18181b] border border-[#27272a] rounded px-1.5 py-0.5 text-center text-xxs text-white"
                  />
                  <input
                    type="color"
                    value={plotBgColor}
                    onChange={(e) => setPlotBgColor(e.target.value)}
                    className="w-6 h-6 cursor-pointer bg-transparent border-0 rounded shrink-0"
                  />
                </div>
              </div>
            </div>

            {/* Cohesive Journal Palettes (Quick Multi-Curve Application) */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2.5">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">Cohesive Multi-curve Palettes</span>
              <p className="text-[10px] text-zinc-500 leading-relaxed">
                Apply peer-review-grade colors across all visible lines of the active stack overlays with a single click:
              </p>
              
              <div className="flex flex-col gap-1.5">
                {/* Nature */}
                <button
                  onClick={() => {
                    const colors = ['#0f172a', '#0d9488', '#10b981', '#84cc16', '#3f6212'];
                    let colorIdx = 0;
                    const list = datasets.map(d => {
                      if (d.visible) {
                        const c = colors[colorIdx % colors.length];
                        colorIdx++;
                        return { ...d, color: c };
                      }
                      return d;
                    });
                    onDatasetsUpdated(list);
                  }}
                  className="w-full flex items-center justify-between text-left text-xxs bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] p-1.5 rounded transition"
                >
                  <span className="font-semibold text-zinc-300">Nature Portfolio (Muted Teals/Sages)</span>
                  <div className="flex gap-1 shrink-0">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0f172a]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0d9488]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#84cc16]" />
                  </div>
                </button>

                {/* ACS */}
                <button
                  onClick={() => {
                    const colors = ['#1e3a8a', '#b91c1c', '#d97706', '#0369a1', '#4b5563'];
                    let colorIdx = 0;
                    const list = datasets.map(d => {
                      if (d.visible) {
                        const c = colors[colorIdx % colors.length];
                        colorIdx++;
                        return { ...d, color: c };
                      }
                      return d;
                    });
                    onDatasetsUpdated(list);
                  }}
                  className="w-full flex items-center justify-between text-left text-xxs bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] p-1.5 rounded transition"
                >
                  <span className="font-semibold text-zinc-300">ACS Classic (Indigo/Amber/Navy)</span>
                  <div className="flex gap-1 shrink-0">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#1e3a8a]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#b91c1c]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#d97706]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0369a1]" />
                  </div>
                </button>

                {/* RSC Georgia */}
                <button
                  onClick={() => {
                    const colors = ['#be123c', '#0f172a', '#b45309', '#6d28d9', '#4b5563'];
                    let colorIdx = 0;
                    const list = datasets.map(d => {
                      if (d.visible) {
                        const c = colors[colorIdx % colors.length];
                        colorIdx++;
                        return { ...d, color: c };
                      }
                      return d;
                    });
                    onDatasetsUpdated(list);
                  }}
                  className="w-full flex items-center justify-between text-left text-xxs bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] p-1.5 rounded transition"
                >
                  <span className="font-semibold text-zinc-300">RSC Georgia (Crimson/Tyrian)</span>
                  <div className="flex gap-1 shrink-0">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#be123c]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0f172a]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#b45309]" />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#6d28d9]" />
                  </div>
                </button>

                {/* Grayscale */}
                <button
                  onClick={() => {
                    const colors = ['#000000', '#4b5563', '#888888', '#cccccc', '#555555'];
                    let colorIdx = 0;
                    let dashStyles = ['solid', 'dashed', 'dotted', 'solid', 'dashed'];
                    const list = datasets.map(d => {
                      if (d.visible) {
                        const c = colors[colorIdx % colors.length];
                        const s = dashStyles[colorIdx % dashStyles.length];
                        colorIdx++;
                        return { ...d, color: c, lineStyle: s as any };
                      }
                      return d;
                    });
                    onDatasetsUpdated(list);
                  }}
                  className="w-full flex items-center justify-between text-left text-xxs bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] p-1.5 rounded transition"
                >
                  <span className="font-semibold text-zinc-300">Monochromatic Publication (Dashed)</span>
                  <div className="flex gap-1 shrink-0">
                    <span className="w-2.5 h-2.5 rounded bg-black" />
                    <span className="w-2.5 h-2.5 rounded bg-zinc-600" />
                    <span className="w-2.5 h-2.5 rounded bg-zinc-400" />
                    <span className="w-2.5 h-2.5 rounded bg-zinc-200" />
                  </div>
                </button>
              </div>
            </div>

            {/* Custom axis boundaries labels */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">Manual Axes Bounds & Grid Overrides</span>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">X axis Label</span>
                  <input
                    type="text"
                    value={xLabel}
                    onChange={(e) => setXLabel(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs"
                    placeholder="Wavelength, λ (nm)"
                  />
                </div>
                <div>
                  <span className="text-[10px] text-gray-500 block mb-0.5">Y axis Label</span>
                  <input
                    type="text"
                    value={yLabel}
                    onChange={(e) => setYLabel(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs"
                    placeholder="Absorbance (a.u.)"
                  />
                </div>
              </div>

              {/* Grid switches */}
              <div className="flex gap-4 py-1 select-none">
                <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-gray-400">
                  <input type="checkbox" checked={gridX} onChange={(e) => setGridX(e.target.checked)} className="accent-teal-500 rounded" /> Show X grid
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-gray-400">
                  <input type="checkbox" checked={gridY} onChange={(e) => setGridY(e.target.checked)} className="accent-teal-500 rounded" /> Show Y grid
                </label>
              </div>

              {/* X Bounds fields */}
              <div className="border-t border-[#1e1e24] pt-2 flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-400">Auto X Bounds</span>
                  <input type="checkbox" checked={autoX} onChange={(e) => setAutoX(e.target.checked)} className="accent-teal-500 rounded" />
                </div>
                {!autoX && (
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      value={manualXMin}
                      onChange={(e) => setManualXMin(Number(e.target.value))}
                      className="bg-[#18181b] border border-[#27272a] rounded p-1 text-center"
                      placeholder="min"
                    />
                    <input
                      type="number"
                      value={manualXMax}
                      onChange={(e) => setManualXMax(Number(e.target.value))}
                      className="bg-[#18181b] border border-[#27272a] rounded p-1 text-center"
                      placeholder="max"
                    />
                  </div>
                )}
              </div>

              {/* Y Bounds fields */}
              <div className="border-t border-[#1e1e24] pt-2 flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-400">Auto Y Bounds</span>
                  <input type="checkbox" checked={autoY} onChange={(e) => setAutoY(e.target.checked)} className="accent-teal-500 rounded" />
                </div>
                {!autoY && (
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      value={manualYMin}
                      onChange={(e) => setManualYMin(Number(e.target.value))}
                      className="bg-[#18181b] border border-[#27272a] rounded p-1 text-center"
                      placeholder="min"
                    />
                    <input
                      type="number"
                      value={manualYMax}
                      onChange={(e) => setManualYMax(Number(e.target.value))}
                      className="bg-[#18181b] border border-[#27272a] rounded p-1 text-center"
                      placeholder="max"
                    />
                  </div>
                )}
              </div>

              {/* Advanced spectroscopic axis inversion */}
              <div className="border-t border-[#1e1e24] pt-2.5 flex flex-col gap-2">
                <span className="text-xxs font-semibold uppercase text-zinc-400">Spectroscopic Axis Inversion</span>
                <div className="grid grid-cols-2 gap-2">
                  <label className="flex items-center gap-1.5 cursor-pointer text-[10.5px] text-gray-400 hover:text-white select-none">
                    <input
                      type="checkbox"
                      checked={invertX}
                      onChange={(e) => setInvertX(e.target.checked)}
                      className="accent-teal-500 rounded"
                    />
                    Invert X-Axis <span className="text-[10px] text-zinc-500 font-mono">(NMR/FTIR)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-[10.5px] text-gray-400 hover:text-white select-none">
                    <input
                      type="checkbox"
                      checked={invertY}
                      onChange={(e) => setInvertY(e.target.checked)}
                      className="accent-teal-500 rounded"
                    />
                    Invert Y-Axis <span className="text-[10px] text-zinc-500 font-mono">(%Trans.)</span>
                  </label>
                </div>
              </div>

              {/* Major Tick Step Sizes & Minor Ticks Count */}
              <div className="border-t border-[#1e1e24] pt-2.5 flex flex-col gap-2">
                <span className="text-xxs font-semibold uppercase text-zinc-400">Major Tick Manual Intervals</span>
                <div className="grid grid-cols-3 gap-1.5">
                  <div>
                    <span className="text-[9px] text-gray-500 block mb-0.5">X Tick Step</span>
                    <input
                      type="number"
                      value={tickStepX || ''}
                      onChange={(e) => setTickStepX(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-center text-xs text-white"
                      placeholder="Auto"
                      min={0}
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-gray-500 block mb-0.5">Y Tick Step</span>
                    <input
                      type="number"
                      value={tickStepY || ''}
                      onChange={(e) => setTickStepY(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-center text-xs text-white"
                      placeholder="Auto"
                      min={0}
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-gray-500 block mb-0.5">Sub-ticks Count</span>
                    <select
                      value={minorTicksCount}
                      onChange={(e) => setMinorTicksCount(parseInt(e.target.value) || 0)}
                      className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-center text-xs text-white"
                    >
                      <option value="0">None</option>
                      <option value="1">1 sub-tick</option>
                      <option value="3">3 sub-ticks</option>
                      <option value="4">4 sub-ticks (ACS)</option>
                      <option value="9">9 sub-ticks</option>
                    </select>
                  </div>
                </div>
                <p className="text-[9px] text-zinc-500 leading-relaxed">
                  ACS and Nature specify major ticks alignment alongside minor ticks to maximize peak scanning accuracy. Set X/Y Step to "0" to revert to automatic tick placement.
                </p>
              </div>
            </div>

            {/* Inward Thick Axes, drop-lines, legend option controls */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2 font-medium text-gray-400 select-none">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={thickAxes} onChange={(e) => setThickAxes(e.target.checked)} className="accent-teal-500" /> Thick border boxed & inward ticks
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={dropLines} onChange={(e) => setDropLines(e.target.checked)} className="accent-teal-500" /> Draw vertical drops-line at Peak marks
              </label>
              
              <div className="border-t border-[#1e1e24] pt-2 flex items-center justify-between mt-1">
                <span className="text-[11px]">Expose Legend Box</span>
                <input type="checkbox" checked={showLegend} onChange={(e) => setShowLegend(e.target.checked)} className="accent-teal-500" />
              </div>
              {showLegend && (
                <div className="flex items-center justify-between text-[10px] mt-1">
                  <span>Legend Position</span>
                  <select value={legendPos} onChange={(e) => setLegendPos(e.target.value)} className="bg-[#18181b] border border-[#27272a] p-1 rounded">
                    <option value="upper right">Upper Right</option>
                    <option value="upper left">Upper Left</option>
                    <option value="lower right">Lower Right</option>
                    <option value="lower left">Lower Left</option>
                  </select>
                </div>
              )}
            </div>

          </motion.div>
        )}

        {/* ==========================================
            TAB 4: LAYOUT & CONVERTER EXPORTS
            ========================================== */}
        {activeTab === 'export' && (
          <motion.div
            key="tab-export"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex flex-col gap-4"
          >
            
            {/* View Stack modes */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-3">
              <span className="block text-xxs font-semibold uppercase text-zinc-400">View Layout Projection Style</span>
              
              <div className="flex flex-col gap-2">
                <select
                  value={layoutMode}
                  onChange={(e) => {
                    const val = e.target.value as any;
                    if (!isPremium && (val === 'Waterfall Stack (3D Projection)' || val === '2D Heatmap / Contour Plot')) {
                      onTriggerUpgrade();
                    } else {
                      setLayoutMode(val);
                    }
                  }}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-xs text-white"
                >
                  <option value="Standard Overlay">Standard Overlay Stack (Free)</option>
                  <option value="Waterfall Stack (3D Projection)">Waterfall Stack (3D Projection) {!isPremium && "🔒 Pro"}</option>
                  <option value="2D Heatmap / Contour Plot">2D Heatmap / Contour Plot {!isPremium && "🔒 Pro"}</option>
                </select>

                {layoutMode === 'Waterfall Stack (3D Projection)' && (
                  <div className="mt-1">
                    <span className="text-[10px] text-gray-500 block mb-1">3D Oblique spacing scale ({(waterfallOffset * 100).toFixed(0)}%)</span>
                    <input
                      type="range"
                      min={0}
                      max={1.5}
                      step={0.1}
                      value={waterfallOffset}
                      onChange={(e) => setWaterfallOffset(Number(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Specialized Journal Export Configuration Panel */}
            <div className="bg-[#09090b] p-3.5 rounded-lg border border-[#27272a] flex flex-col gap-3">
              <div className="flex items-center gap-1.5 border-b border-[#1e1e24] pb-1.5 mb-1">
                <Sliders size={13} className="text-teal-400" />
                <span className="block text-xxs font-bold uppercase tracking-wide text-zinc-300">Journal Publication Cover & Figure Export</span>
              </div>

              {/* Layout options inside panel */}
              <div className="grid grid-cols-2 gap-2 text-xxs">
                <div className="flex flex-col gap-1">
                  <span className="text-zinc-400 font-semibold uppercase font-mono text-[9px]">Target Specification</span>
                  <select
                    value={journalStyleOverride}
                    onChange={(e) => setJournalStyleOverride(e.target.value as any)}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white"
                  >
                    <option value="ACS">ACS (Arial, thick line, boxed)</option>
                    <option value="RSC">RSC (Times New Roman, serif)</option>
                    <option value="Nature">Nature (compact, light-weight)</option>
                    <option value="Default">Default Standard Modern</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-zinc-400 font-semibold uppercase font-mono text-[9px]">Resolution Density</span>
                  <select
                    value={exportDPI}
                    onChange={(e) => {
                      const val = Number(e.target.value) as any;
                      if (!isPremium && (val === 600 || val === 1200)) {
                        onTriggerUpgrade();
                      } else {
                        setExportDPI(val);
                      }
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white"
                  >
                    <option value="300">300 DPI (Standard Journal)</option>
                    <option value="600">600 DPI (Pro High-Res) {!isPremium && "🔒 Pro"}</option>
                    <option value="1200">1200 DPI (Pro Line Art) {!isPremium && "🔒 Pro"}</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-zinc-400 font-semibold uppercase font-mono text-[9px]">Lossless Format Encoding</span>
                  <select
                    value={exportFormat}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      if (!isPremium && val === 'tiff') {
                        onTriggerUpgrade();
                      } else {
                        setExportFormat(val);
                      }
                    }}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-white"
                  >
                    <option value="png">Uncompressed PNG (Lossless)</option>
                    <option value="tiff">Lossless TIFF Surrogate (.tiff) {!isPremium && "🔒 Pro"}</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-zinc-400 font-semibold uppercase font-mono text-[9px]">Physical Dimension</span>
                  <div className="bg-[#18181b] border border-[#27272a] rounded p-1 text-[11px] text-zinc-400 font-mono text-center">
                    {journalStyleOverride === 'ACS' ? "3.25 in (Single Col)" : journalStyleOverride === 'Nature' ? "89 mm (Compact)" : "8.2 cm (Standard)"}
                  </div>
                </div>
              </div>

              <button
                disabled={exportStates.highDpi === 'loading'}
                onClick={() => {
                  if (!isPremium && (exportDPI === 600 || exportDPI === 1200 || exportFormat === 'tiff')) {
                    onTriggerUpgrade();
                    return;
                  }
                  if (!isPremium && exportCount >= 2) {
                    onTriggerUpgrade();
                    return;
                  }
                  setExportStates(prev => ({ ...prev, highDpi: 'loading' }));

                  setTimeout(() => {
                    if ((window as any).exportHighDPIImage) {
                      (window as any).exportHighDPIImage(exportDPI, exportFormat, journalStyleOverride);
                      if (!isPremium) {
                        setExportCount(prev => prev + 1);
                      }
                      setExportStates(prev => ({ ...prev, highDpi: 'success' }));

                      const filename = `${journalStyleOverride || journalStyle}_Figure_${exportDPI}DPI.${exportFormat}`;
                      triggerToast(
                        "Lossless Graphic Rendered",
                        `Rasterized high-definition ${exportFormat.toUpperCase()} publication layout (${exportDPI} DPI) successfully.`,
                        filename,
                        () => {
                          if ((window as any).exportHighDPIImage) {
                            (window as any).exportHighDPIImage(exportDPI, exportFormat, journalStyleOverride);
                          }
                        }
                      );

                      setTimeout(() => {
                        setExportStates(prev => ({ ...prev, highDpi: 'idle' }));
                      }, 3000);
                    } else {
                      setExportStates(prev => ({ ...prev, highDpi: 'idle' }));
                      alert("Failure executing High-Res Canvas rasterization.");
                    }
                  }, 850);
                }}
                className={`w-full font-bold py-1.5 px-3 rounded uppercase text-[10px] tracking-wider transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer select-none ${
                  exportStates.highDpi === 'success'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-teal-600 hover:bg-teal-500 text-white'
                }`}
              >
                {exportStates.highDpi === 'loading' ? (
                  <>
                    <Loader2 size={13} className="animate-spin text-teal-200" />
                    <span>Processing rasterization...</span>
                  </>
                ) : exportStates.highDpi === 'success' ? (
                  <>
                    <Check size={13} className="text-emerald-200 scale-110" />
                    <span>Export Success!</span>
                  </>
                ) : (
                  <>
                    <Download size={13} />
                    <span>Render & Export {exportFormat.toUpperCase()} ({exportDPI} DPI)</span>
                  </>
                )}
              </button>
            </div>

            {/* Picture-in-picture insets */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xxs font-semibold uppercase text-zinc-400">Enlarge zoomed Inset (Sub-frame)</span>
                <input type="checkbox" checked={enableInset} onChange={(e) => setEnableInset(e.target.checked)} className="accent-teal-500 rounded" />
              </div>

              {enableInset && (
                <div className="grid grid-cols-2 gap-2 mt-1">
                  <div>
                    <span className="text-[10px] text-zinc-500 block">Min X</span>
                    <input type="number" value={insetXMin} onChange={(e) => setInsetXMin(Number(e.target.value))} className="w-full bg-[#18181b] border border-[#27272a] text-center" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 block">Max X</span>
                    <input type="number" value={insetXMax} onChange={(e) => setInsetXMax(Number(e.target.value))} className="w-full bg-[#18181b] border border-[#27272a] text-center" />
                  </div>
                </div>
              )}
            </div>

            {/* Colored highlighted backgrounds */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xxs font-semibold uppercase text-zinc-400">Active Highlight Span</span>
                <input type="checkbox" checked={enableHighlight} onChange={(e) => setEnableHighlight(e.target.checked)} className="accent-teal-500 rounded" />
              </div>

              {enableHighlight && (
                <div className="grid grid-cols-2 gap-2 mt-1">
                  <div>
                    <span className="text-[10px] text-zinc-500 block">Start span</span>
                    <input type="number" value={highlightMin} onChange={(e) => setHighlightMin(Number(e.target.value))} className="w-full bg-[#18181b] border border-[#27272a] text-center" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 block">End span</span>
                    <input type="number" value={highlightMax} onChange={(e) => setHighlightMax(Number(e.target.value))} className="w-full bg-[#18181b] border border-[#27272a] text-center" />
                  </div>
                </div>
              )}
            </div>

            {/* SVD PCA trigger button & actions */}
            <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2 border-l-2 border-amber-500/50">
              <span className="block text-xxs font-semibold uppercase text-amber-400">Multivariate SVD Decompositions</span>
              <button
                onClick={handleCalculatePCA}
                className="w-full bg-amber-600 hover:bg-amber-500 text-white font-semibold py-1.5 px-3 rounded uppercase text-[10px] tracking-wider transition"
              >
                Execute Singular PCA
              </button>
            </div>

            {/* Document export downloads */}
            <div className="border-t border-[#27272a] pt-4 flex flex-col gap-2">
              <button
                disabled={exportStates.svg === 'loading'}
                onClick={() => {
                  if (!isPremium && exportCount >= 2) {
                    onTriggerUpgrade();
                    return;
                  }

                  setExportStates(prev => ({ ...prev, svg: 'loading' }));

                  setTimeout(() => {
                    if ((window as any).exportChartAsSVG) {
                      (window as any).exportChartAsSVG();
                      if (!isPremium) {
                        setExportCount(prev => prev + 1);
                      }
                      setExportStates(prev => ({ ...prev, svg: 'success' }));

                      const filename = `SpectraForge_Export_${Date.now()}.svg`;
                      triggerToast(
                        "Vector Figure Exported",
                        "Scaled vector element (.svg) generated mathematically. Ideal for inline XML embedding or print drafts.",
                        filename,
                        () => {
                          if ((window as any).exportChartAsSVG) {
                            (window as any).exportChartAsSVG();
                          }
                        }
                      );

                      setTimeout(() => {
                        setExportStates(prev => ({ ...prev, svg: 'idle' }));
                      }, 3000);
                    } else {
                      setExportStates(prev => ({ ...prev, svg: 'idle' }));
                      alert("Export system initialization failure.");
                    }
                  }, 850);
                }}
                className={`w-full flex items-center justify-center gap-1.5 border py-2 px-4 rounded text-xs font-semibold shadow transition-all select-none cursor-pointer ${
                  exportStates.svg === 'success'
                    ? 'bg-[#15803d]/90 hover:bg-emerald-600 border-emerald-600 text-white'
                    : 'bg-[#27272a] hover:bg-[#3f3f46] border-[#3f3f46] text-teal-400'
                }`}
              >
                {exportStates.svg === 'loading' ? (
                  <>
                    <Loader2 size={14} className="animate-spin text-teal-200 font-bold" />
                    <span>Processing Vector Render...</span>
                  </>
                ) : exportStates.svg === 'success' ? (
                  <>
                    <Check size={14} className="text-emerald-205 scale-110" />
                    <span>Vector Saved Successfully!</span>
                  </>
                ) : (
                  <>
                    <Download size={14} />
                    <span>Download Vector Figure (.svg) {!isPremium && `(${2 - exportCount > 0 ? 2 - exportCount : 0} Free Left)`}</span>
                  </>
                )}
              </button>

              <button
                disabled={exportStates.python === 'loading'}
                onClick={() => {
                  if (!isPremium) {
                    onTriggerUpgrade();
                    return;
                  }

                  setExportStates(prev => ({ ...prev, python: 'loading' }));

                  setTimeout(() => {
                    try {
                      const code = generatePythonTkinterCode(sd);
                      const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
                      const url = URL.createObjectURL(blob);
                      const link = document.createElement('a');
                      link.href = url;
                      const filename = `spectra_forge_${sd.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_gui.py`;
                      link.download = filename;
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);

                      setExportStates(prev => ({ ...prev, python: 'success' }));

                      triggerToast(
                        "Python Script Generated",
                        "Tkinter GUI workspace script initialized with complete spectrum variables successfully.",
                        filename,
                        () => {
                          const reLink = document.createElement('a');
                          reLink.href = url;
                          reLink.download = filename;
                          document.body.appendChild(reLink);
                          reLink.click();
                          document.body.removeChild(reLink);
                        }
                      );

                      setTimeout(() => {
                        setExportStates(prev => ({ ...prev, python: 'idle' }));
                      }, 3000);
                    } catch (err: any) {
                      setExportStates(prev => ({ ...prev, python: 'idle' }));
                      alert("Failed to export python tkinter workspace: " + (err.message || err));
                    }
                  }, 850);
                }}
                className={`w-full flex items-center justify-center gap-1.5 border py-2 px-4 rounded text-xs font-semibold shadow transition-all select-none cursor-pointer ${
                  exportStates.python === 'success'
                    ? 'bg-[#15803d]/90 hover:bg-emerald-600 border-emerald-600 text-white'
                    : 'bg-teal-950/40 hover:bg-teal-900/40 border-teal-500/20 text-teal-400'
                }`}
              >
                {exportStates.python === 'loading' ? (
                  <>
                    <Loader2 size={14} className="animate-spin text-teal-200" />
                    <span>Compiling Python Code...</span>
                  </>
                ) : exportStates.python === 'success' ? (
                  <>
                    <Check size={14} className="text-emerald-205 scale-110" />
                    <span>Python Script Exported!</span>
                  </>
                ) : (
                  <>
                    <Sliders size={14} className="text-teal-400" />
                    <span>Export Standalone Python GUI (.py) {!isPremium && "🔒 Pro"}</span>
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  disabled={exportStates.csv === 'loading'}
                  onClick={handleExportCSVReport}
                  className={`flex items-center gap-1.5 border text-xxs justify-center transition py-1.5 px-2 rounded cursor-pointer select-none ${
                    exportStates.csv === 'success'
                      ? 'bg-emerald-700/85 hover:bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-[#27272a] hover:bg-[#18181b] border-[#3f3f46] text-zinc-300 hover:text-teal-400'
                  }`}
                >
                  {exportStates.csv === 'loading' ? (
                    <Loader2 size={13} className="animate-spin text-zinc-400" />
                  ) : exportStates.csv === 'success' ? (
                    <Check size={13} className="text-emerald-250" />
                  ) : (
                    <FileSpreadsheet size={13} className="text-zinc-500" />
                  )}
                  <span>{exportStates.csv === 'loading' ? "Exporting..." : exportStates.csv === 'success' ? "Exported!" : "Export CSV"}</span>
                </button>

                <button
                  disabled={exportStates.markdown === 'loading'}
                  onClick={handleExportMarkdownReport}
                  className={`flex items-center gap-1.5 border text-xxs justify-center transition py-1.5 px-2 rounded cursor-pointer select-none ${
                    exportStates.markdown === 'success'
                      ? 'bg-emerald-700/85 hover:bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-[#27272a] hover:bg-[#18181b] border-[#3f3f46] text-zinc-300 hover:text-teal-400'
                  }`}
                >
                  {exportStates.markdown === 'loading' ? (
                    <Loader2 size={13} className="animate-spin text-zinc-400" />
                  ) : exportStates.markdown === 'success' ? (
                    <Check size={13} className="text-emerald-250" />
                  ) : (
                    <FileText size={13} className="text-zinc-500" />
                  )}
                  <span>{exportStates.markdown === 'loading' ? "Exporting..." : exportStates.markdown === 'success' ? "Exported!" : "Export MD"}</span>
                </button>
              </div>

              <button
                disabled={exportStates.pdf === 'loading'}
                onClick={() => setIsPdfPreviewOpen(true)}
                className={`w-full flex items-center justify-center gap-1.5 border py-2 px-4 rounded text-xs font-semibold shadow transition-all select-none cursor-pointer ${
                  exportStates.pdf === 'success'
                    ? 'bg-[#15803d]/90 hover:bg-[#16a34a] border-emerald-600'
                    : 'bg-emerald-950/40 hover:bg-emerald-900/30 border-teal-500/20 text-teal-400'
                }`}
              >
                {exportStates.pdf === 'loading' ? (
                  <>
                    <Loader2 size={14} className="animate-spin text-teal-200" />
                    <span>Assembling PDF Preview...</span>
                  </>
                ) : exportStates.pdf === 'success' ? (
                  <>
                    <Check size={14} className="text-emerald-250 scale-110" />
                    <span>PDF Report Exported!</span>
                  </>
                ) : (
                  <>
                    <FileText size={14} className="text-teal-400" />
                    <span>Preview & Export PDF Report (.pdf)</span>
                  </>
                )}
              </button>

              {/* Journal Experimental Methodology Paragraph generator */}
              <div className="border-t border-[#27272a] mt-2.5 pt-3.5 flex flex-col gap-2">
                <span className="block text-xxs font-semibold uppercase text-teal-400 tracking-wider">Experimental & Methods Copywriter</span>
                <p className="text-[10px] text-zinc-400 leading-normal">
                  Copy-paste this live methodology description directly into your paper's Supporting Information:
                </p>
                
                <div className="bg-[#09090b] p-3 rounded border border-[#27272a] flex flex-col gap-2.5">
                  <div className="text-[10px] text-emerald-400 font-mono leading-relaxed select-all bg-[#18181b] p-2.5 rounded border border-[#27272a] max-h-[140px] overflow-y-auto scrollbar-thin">
                    {`Experimental Spectroscopy Methodology: The raw spectrum "${sd.name}" was processed and formatted using the Labscribber Pro spectroscopy workstation. Active peak deconvolution maps major emission or absorption bands at x = [${sd.peaks.map(p => p.x.toFixed(2)).join(', ') || 'N/A'}] ${xLabel.includes('Wavelength') || xLabel.includes('λ') ? 'nm' : 'units'}${sd.peaks.some(p => p.transition) ? ` with explicit assignments for electronic transitions ([${sd.peaks.filter(p => p.transition).map(p => p.transition).join(', ')}])` : ''}. Analytical integration of primary peaks yields a trapezoidal integral area bounds of [${sd.integrals.map(i => `${i.xmin.toFixed(2)}-${i.xmax.toFixed(2)}`).join('; ') || 'N/A'}] representing absolute quantitative band intensities.`}
                  </div>
                  
                  <div className="flex justify-between items-center border-t border-[#27272a] pt-2 text-[10px]">
                    <span className="text-[9px] text-zinc-500 font-medium">JOSS & Cite-Ready:</span>
                    <button
                      onClick={() => {
                        const bibtex = `@article{Razak2026LabscribberPro,
  title={{Labscribber Pro: A High-Provenance Virtual Spectroscopy Workstation and Interactive Peer-to-Peer Plotter}},
  author={Razak, Asif and ChemScribber Research Group},
  journal={Journal of Open Source Software},
  volume={11},
  number={123},
  pages={7489},
  year={2026},
  doi={10.21105/joss.07489},
  url={https://github.com/asifrazak/labscribber}
}`;
                        navigator.clipboard.writeText(bibtex);
                        if (onOpenCiteKit) {
                          onOpenCiteKit();
                        } else {
                          alert("BibTeX citation copied! You can paste it directly into your Zotero or LaTeX references.");
                        }
                      }}
                      className="text-[10px] px-2.5 py-1 bg-teal-950/50 hover:bg-teal-900 border border-teal-500/20 text-teal-400 rounded transition font-semibold flex items-center gap-1"
                    >
                      <span>Cite Labscribber Pro</span>
                    </button>
                  </div>
                </div>
              </div>

            </div>

          </motion.div>
        )}

      </div>

      {/* PCA scores loading modal */}
      {isPcaModalOpen && pcaResult && (() => {
        const visibleDatasets = datasets.filter(d => d.visible);
        
        // Centroid
        let meanPC1 = 0;
        let meanPC2 = 0;
        visibleDatasets.forEach((_, sIdx) => {
          const rowScores = pcaResult.scores[sIdx];
          if (rowScores) {
            meanPC1 += rowScores[0] || 0;
            meanPC2 += rowScores[1] || 0;
          }
        });
        meanPC1 /= visibleDatasets.length || 1;
        meanPC2 /= visibleDatasets.length || 1;

        // Euclidean distance from centroid
        const distances = visibleDatasets.map((_, sIdx) => {
          const rowScores = pcaResult.scores[sIdx];
          if (!rowScores) return 0;
          const dx = (rowScores[0] || 0) - meanPC1;
          const dy = (rowScores[1] || 0) - meanPC2;
          return Math.sqrt(dx * dx + dy * dy);
        });

        const meanDist = distances.reduce((sum, d) => sum + d, 0) / (distances.length || 1);
        const varianceDist = distances.reduce((sum, d) => sum + Math.pow(d - meanDist, 2), 0) / (distances.length || 1);
        const stdDist = Math.sqrt(varianceDist) || 1e-9;

        // Standard scientific threshold: distance > mean + 1.2 * std deviation
        const thres = meanDist + 1.2 * stdDist;

        const analysisRows = visibleDatasets.map((ds, sIdx) => {
          const rowScores = pcaResult.scores[sIdx] || [0, 0];
          const dist = distances[sIdx];
          const zScore = (dist - meanDist) / stdDist;
          // If there are only 2 or 3 samples, mark the furthest one as potential outlier to assist
          const isFurthest = dist === Math.max(...distances);
          const isOutlier = dist > thres || (visibleDatasets.length <= 4 && isFurthest && dist > meanDist * 1.3);

          return {
            id: ds.id,
            name: ds.name,
            color: ds.color,
            pc1: rowScores[0] || 0,
            pc2: rowScores[1] || 0,
            dist,
            zScore,
            isOutlier
          };
        });

        const identifiedOutliers = analysisRows.filter(r => r.isOutlier);

        // Compute coordinates for SVG layout mapping
        const pc1Vals = analysisRows.map(r => r.pc1);
        const pc2Vals = analysisRows.map(r => r.pc2);
        
        let minPC1 = Math.min(...pc1Vals, -1);
        let maxPC1 = Math.max(...pc1Vals, 1);
        let minPC2 = Math.min(...pc2Vals, -1);
        let maxPC2 = Math.max(...pc2Vals, 1);

        // Add 20% cushion to borders
        const padPC1 = (maxPC1 - minPC1) * 0.2 || 0.5;
        const padPC2 = (maxPC2 - minPC2) * 0.2 || 0.5;
        minPC1 -= padPC1; maxPC1 += padPC1;
        minPC2 -= padPC2; maxPC2 += padPC2;

        const mapX = (v: number) => 30 + ((v - minPC1) / (maxPC1 - minPC1 || 1)) * 280;
        const mapY = (v: number) => 210 - ((v - minPC2) / (maxPC2 - minPC2 || 1)) * 180;

        const handleDownloadPCAPlot = () => {
          // Generates high quality vector dump of PCA model
          let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 340 240" width="600" height="423" style="background:#09090b; font-family:sans-serif;">`;
          s += `<rect width="340" height="240" fill="#09090b"/>`;
          
          // Axes labels
          s += `<text x="170" y="235" fill="#a1a1aa" font-size="9" text-anchor="middle">PC1 (Explained Var: ${(pcaResult.explainedVariance[0]*100).toFixed(1)}%)</text>`;
          s += `<text x="10" y="120" fill="#a1a1aa" font-size="9" text-anchor="middle" transform="rotate(-90 10 120)">PC2 (Explained Var: ${(pcaResult.explainedVariance[1]*100).toFixed(1)}%)</text>`;

          // Zero intercept lines
          const zeroX = mapX(0);
          const zeroY = mapY(0);
          if (zeroX >= 30 && zeroX <= 310) {
            s += `<line x1="${zeroX}" y1="30" x2="${zeroX}" y2="210" stroke="#27272a" stroke-dasharray="3,3"/>`;
          }
          if (zeroY >= 30 && zeroY <= 210) {
            s += `<line x1="30" y1="${zeroY}" x2="310" y2="${zeroY}" stroke="#27272a" stroke-dasharray="3,3"/>`;
          }

          // Plot grid box border
          s += `<rect x="30" y="30" width="280" height="180" fill="none" stroke="#27272a" stroke-width="1"/>`;

          // Plot coordinate points & names
          analysisRows.forEach((r) => {
            const cx = mapX(r.pc1);
            const cy = mapY(r.pc2);
            if (r.isOutlier) {
              s += `<circle cx="${cx}" cy="${cy}" r="9" fill="none" stroke="#f43f5e" stroke-width="1.5" stroke-dasharray="2,2"/>`;
            }
            s += `<circle cx="${cx}" cy="${cy}" r="5" fill="${r.color || '#3b82f6'}"/>`;
            s += `<text x="${cx + 7}" y="${cy + 3}" fill="#e4e4e7" font-size="8">${r.name}</text>`;
          });

          s += `</svg>`;
          const blob = new Blob([s], { type: 'image/svg+xml;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `PCA_Variance_Cluster_${Date.now()}.svg`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        };

        return (
          <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[#121214] border border-[#27272a] rounded-xl shadow-2xl p-6 w-full max-w-4xl text-gray-200 flex flex-col gap-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-[#27272a] pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="text-amber-400" size={18} />
                  <h3 className="text-sm font-semibold tracking-wide text-zinc-100 uppercase">
                    Multivariate Variance Analysis & Outlier Detector
                  </h3>
                </div>
                <span className="text-[10px] bg-amber-500/10 text-amber-400 font-mono px-2 py-0.5 rounded border border-amber-500/20">
                  SVD-NIPALS PCA Engine Enabled
                </span>
              </div>
              
              <p className="text-[11px] text-gray-400 leading-relaxed -mt-2">
                Singular Value Decomposition executed successfully across {visibleDatasets.length} spectra. Each dimension represents structural features of variance. Points deviating significantly from cluster centroid are highlighted as statistical outliers.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
                {/* Left: Explained Variance & Outliers Alert */}
                <div className="md:col-span-4 flex flex-col gap-3">
                  <div className="border border-[#27272a] bg-[#09090b] rounded-lg p-3 flex flex-col gap-2.5">
                    <span className="text-[10px] font-bold uppercase text-gray-400 tracking-wider">Eigenvalue Variance Breakdown</span>
                    <div className="flex flex-col gap-3">
                      {pcaResult.explainedVariance.map((variance, idx) => (
                        <div key={idx} className="flex flex-col gap-1 text-xxs">
                          <div className="flex justify-between text-[11px]">
                            <span className="font-semibold text-zinc-300">Principal Component {idx + 1}</span>
                            <span className="text-amber-400 font-bold">{(variance * 100).toFixed(2)}%</span>
                          </div>
                          <div className="w-full bg-[#1e1e24] h-2 rounded-full overflow-hidden border border-zinc-800">
                            <div className="bg-amber-500 h-full rounded-full" style={{ width: `${variance * 105}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Statistical Outliers Card */}
                  <div className={`p-3.5 rounded-lg border flex flex-col gap-1.5 ${identifiedOutliers.length > 0 ? 'bg-rose-950/20 border-rose-500/20 text-rose-300' : 'bg-emerald-950/10 border-emerald-500/20 text-emerald-300'}`}>
                    <span className="text-[10px] font-bold uppercase tracking-wider">Outlier Diagnostic Status</span>
                    {identifiedOutliers.length > 0 ? (
                      <div className="flex flex-col gap-1.5">
                        <p className="text-[10px] leading-relaxed">
                          Detected **{identifiedOutliers.length}** sample(s) with spectral variance deviating abnormally from the cluster centroid:
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {identifiedOutliers.map(o => (
                            <span key={o.id} className="text-[9px] bg-rose-500/20 border border-rose-500/40 text-rose-200 px-1.5 py-0.5 rounded font-mono font-bold">
                              {o.name} ({o.zScore > 0 ? `+${o.zScore.toFixed(1)}` : o.zScore.toFixed(1)}σ)
                            </span>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <p className="text-[10px] leading-relaxed"> All visible spectrum profiles remain tightly clustered within the standard statistical variance threshold. No outliers identified.</p>
                    )}
                  </div>
                </div>

                {/* Middle: 2D Interactive Scatter SVG Map */}
                <div className="md:col-span-5 border border-[#27272a] bg-[#09090b] rounded-lg p-3 flex flex-col items-center">
                  <div className="w-full flex justify-between items-center mb-1.5">
                    <span className="text-[10px] font-bold uppercase text-gray-400 tracking-wider">PC1 vs PC2 Cluster Scatter Diagram</span>
                    <button
                      onClick={handleDownloadPCAPlot}
                      className="text-[9px] text-teal-400 bg-teal-950/40 hover:bg-teal-900/40 border border-teal-500/20 px-2 py-0.5 rounded transition font-semibold animate-pulse"
                    >
                      Export SVG
                    </button>
                  </div>

                  {/* Custom SVG scatter plot */}
                  <svg className="w-full h-auto max-w-[340px] bg-[#09090b] border border-zinc-850 rounded-md" viewBox="0 0 340 240">
                    {/* Horizontal zero reference line */}
                    {(() => {
                      const zeroY = mapY(0);
                      if (zeroY >= 30 && zeroY <= 210) {
                        return <line x1="30" y1={zeroY} x2="310" y2={zeroY} stroke="#27272a" strokeWidth={1} strokeDasharray="3,3" />;
                      }
                      return null;
                    })()}

                    {/* Vertical zero reference line */}
                    {(() => {
                      const zeroX = mapX(0);
                      if (zeroX >= 30 && zeroX <= 310) {
                        return <line x1={zeroX} y1="30" x2={zeroX} y2="210" stroke="#27272a" strokeWidth={1} strokeDasharray="3,3" />;
                      }
                      return null;
                    })()}

                    {/* Plot boundary bounding box */}
                    <rect x="30" y="30" width="280" height="180" fill="none" stroke="#3f3f46" strokeWidth={1.2} />

                    {/* Coordinates plot */}
                    {analysisRows.map((r) => {
                      const cx = mapX(r.pc1);
                      const cy = mapY(r.pc2);
                      return (
                        <g key={r.id} className="group">
                          {r.isOutlier && (
                            <circle
                              cx={cx}
                              cy={cy}
                              r={8}
                              fill="none"
                              stroke="#ef4444"
                              strokeWidth={1.5}
                              strokeDasharray="2,2"
                            />
                          )}
                          {/* Interactive point circle */}
                          <circle
                            cx={cx}
                            cy={cy}
                            r={5.5}
                            fill={r.color || '#14b8a6'}
                            className="cursor-pointer transition-all duration-200 hover:r-7 hover:stroke-white hover:stroke-2"
                          />
                          {/* Point title tag */}
                          <text
                            x={cx + 7}
                            y={cy + 3}
                            fill="#f4f4f5"
                            fontSize={8.5}
                            fontWeight="500"
                            className="pointer-events-none drop-shadow-md select-none"
                          >
                            {r.name}
                          </text>
                        </g>
                      );
                    })}

                    {/* Dynamic axes labeling content */}
                    <text x={170} y={235} fill="#71717a" fontSize={9} textAnchor="middle" fontWeight="bold">
                      PC1 Score ({(pcaResult.explainedVariance[0]*100).toFixed(1)}% variance explained)
                    </text>
                    <text x={10} y={120} fill="#71717a" fontSize={9} textAnchor="middle" fontWeight="bold" transform="rotate(-90 10 120)">
                      PC2 Score ({(pcaResult.explainedVariance[1]*100).toFixed(1)}% variance explained)
                    </text>
                  </svg>
                </div>

                {/* Right Side: Coordinate Listings */}
                <div className="md:col-span-3 border border-[#27272a] bg-[#09090b] rounded-lg p-3 flex flex-col overflow-hidden">
                  <span className="text-[10px] font-bold uppercase text-gray-400 mb-2 tracking-wider">Cluster Coordinates Matrix</span>
                  <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-1 text-xxs divide-y divide-[#1e1e24] scrollbar-thin">
                    {analysisRows.map((r) => {
                      return (
                        <div key={r.id} className="flex flex-col py-1.5 gap-0.5 first:pt-0">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-1.5 truncate">
                              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: r.color }} />
                              <span className="font-semibold text-zinc-300 truncate max-w-[100px]">{r.name}</span>
                            </div>
                            {r.isOutlier && (
                              <span className="bg-rose-500/10 text-rose-400 text-[8px] px-1 rounded border border-rose-500/30 font-bold">
                                OUTLIER
                              </span>
                            )}
                          </div>
                          <div className="flex justify-between items-center text-[10px] font-mono mt-0.5">
                            <span className="text-zinc-500">[{r.pc1.toFixed(2)}, {r.pc2.toFixed(2)}]</span>
                            <span className={r.isOutlier ? "text-rose-400 font-bold" : "text-zinc-400"}>
                              {r.zScore > 0 ? `+${r.zScore.toFixed(2)}` : r.zScore.toFixed(2)}σ
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

              <div className="flex justify-end gap-3 border-t border-[#27272a] pt-4 mt-1">
                <button
                  onClick={() => setIsPcaModalOpen(false)}
                  className="bg-zinc-800 hover:bg-zinc-700 text-xs text-white font-medium py-1.5 px-4 border border-[#3f3f46] rounded transition-colors"
                >
                  Close Cluster View
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {/* Floating Toast Notification Deck */}
      <div className="fixed bottom-4 right-4 z-[9999] flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className="pointer-events-auto bg-[#18181b] border border-emerald-500/25 shadow-2xl rounded-lg p-3.5 flex flex-col gap-2.5 text-zinc-100 relative overflow-hidden group mb-1"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex gap-2.5 items-start">
                <div className="bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/35 text-emerald-400 mt-0.5 shadow-inner">
                  <Check size={18} className="stroke-[2.5]" />
                </div>
                <div className="flex-1 flex flex-col min-w-0">
                  <span className="font-semibold text-xs text-zinc-100 tracking-wide">{toast.title}</span>
                  <p className="text-[10px] text-zinc-400 leading-relaxed mt-0.5 pr-2">
                    {toast.message}
                  </p>
                </div>
                <button
                  onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
                  className="text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer p-0.5 text-lg -mt-1.5 -mr-1"
                >
                  &times;
                </button>
              </div>

              <div className="bg-[#121214] border border-[#27272a] rounded p-2 flex items-center justify-between gap-2.5">
                <div className="flex items-center gap-1.5 min-w-0 flex-1">
                  <FileText size={12} className="text-zinc-500 shrink-0" />
                  <span className="text-[10px] font-mono text-zinc-400 truncate">{toast.filename}</span>
                </div>
                <button
                  onClick={toast.onClickDownload}
                  className="px-2.5 py-1 text-[9px] font-semibold text-teal-400 bg-teal-950/40 hover:bg-teal-900/40 border border-teal-500/20 rounded hover:border-teal-400/40 hover:text-teal-300 transition-all shadow-sm flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Download size={10} />
                  <span>Download</span>
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* PDF Report Live Preview Modal */}
      <AnimatePresence>
        {isPdfPreviewOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[99999] bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-[#18181b] border border-[#27272a] rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] flex flex-col overflow-hidden text-zinc-100"
            >
              {/* Header */}
              <div className="border-b border-[#27272a] px-6 py-4 flex items-center justify-between bg-[#1f1f23]">
                <div className="flex items-center gap-2.5">
                  <div className="bg-teal-500/10 p-2 rounded-lg border border-teal-500/35 text-teal-400">
                    <FileText size={20} className="stroke-[2.5]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm tracking-wide text-zinc-100">Academic PDF Report Live Verification</h3>
                    <p className="text-[10px] text-zinc-400 mt-0.5">Verify scientific page layouts, peak identifiers, and integrals database in real-time before compile.</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPdfPreviewOpen(false)}
                  className="bg-[#27272a] hover:bg-[#3f3f46] text-zinc-400 hover:text-white transition px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Close Preview
                </button>
              </div>

              {/* Main content grid */}
              <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
                
                {/* Left Panel: Verification summary & download trigger */}
                <div className="lg:col-span-4 p-6 border-r border-[#27272a] bg-[#121214] flex flex-col justify-between overflow-y-auto max-h-[70vh] lg:max-h-full">
                  <div className="flex flex-col gap-5">
                    <div>
                      <span className="text-[10px] font-semibold text-teal-400 uppercase tracking-widest pl-0.5">Verification Checklist</span>
                      <div className="mt-3 space-y-2.5">
                        <div className="flex items-start gap-2.5 bg-[#18181b] p-3 rounded-lg border border-emerald-500/15">
                          <Check size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-semibold text-zinc-200">High-DPI Waveform Verification</span>
                            <p className="text-[10px] text-zinc-400 mt-0.5">Vector-reconstructed curve paths matched exactly with experimental baseline filters.</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2.5 bg-[#18181b] p-3 rounded-lg border border-teal-500/15">
                          <Check size={14} className="text-teal-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-semibold text-zinc-200">Integrations Boundary Validation</span>
                            <p className="text-[10px] text-zinc-400 mt-0.5">Calculated shaded regions, trapezoidal integration bounds are mapped accurately.</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2.5 bg-[#18181b] p-3 rounded-lg border border-zinc-700/50">
                          <Check size={14} className="text-zinc-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-semibold text-zinc-300">Semantic Preprocessing Log</span>
                            <p className="text-[10px] text-zinc-400 mt-0.5">Prism pipeline modifications history appended sequentially to Appendix section.</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Metadata summary table */}
                    <div className="bg-[#18181b] border border-[#27272a] rounded-lg p-4">
                      <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider block mb-2.5">Document Metadata Overview</span>
                      <div className="space-y-2 text-[10px] text-zinc-400 font-mono">
                        <div className="flex justify-between border-b border-[#27272a] pb-1.5">
                          <span>Dataset:</span>
                          <span className="text-zinc-200 truncate max-w-[140px]">{sd.name}</span>
                        </div>
                        <div className="flex justify-between border-b border-[#27272a] pb-1.5">
                          <span>Technique:</span>
                          <span className="text-zinc-200">{sd.technique}</span>
                        </div>
                        <div className="flex justify-between border-b border-[#27272a] pb-1.5">
                          <span>Total Points:</span>
                          <span className="text-zinc-200">{sd.x.length} pts</span>
                        </div>
                        <div className="flex justify-between border-b border-[#27272a] pb-1.5">
                          <span>Detected Peaks:</span>
                          <span className="text-emerald-400 font-semibold">{sd.peaks.length} marks</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Active Integrals:</span>
                          <span className="text-teal-400 font-semibold">{sd.integrals.length} areas</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-5 border-t border-[#27272a]">
                    <button
                      onClick={() => {
                        handleExportPDFReport();
                        setIsPdfPreviewOpen(false);
                      }}
                      className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold py-3 px-4 rounded-lg text-xs tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer select-none"
                    >
                      <Download size={15} />
                      <span>COMPILE & DOWNLOAD PDF REPORT</span>
                    </button>
                    <p className="text-[9px] text-zinc-500 text-center mt-2">Outputs a premium 3-page publication-ready medical/engineering PDF draft.</p>
                  </div>
                </div>

                {/* Right Panel: Scrollable preview deck */}
                <div className="lg:col-span-8 p-6 bg-[#09090b] overflow-y-auto max-h-[70vh] lg:max-h-full flex flex-col gap-8 items-center scrollbar-thin">
                  
                  {/* Virtual PDF Page 1 */}
                  <div className="w-[100%] max-w-[650px] aspect-[1/1.414] bg-white border border-zinc-200 shadow-xl rounded p-[30px] flex flex-col text-zinc-900 justify-between">
                    <div>
                      {/* Stylized top banner */}
                      <div className="w-full h-1 bg-teal-500 mb-4" />
                      
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-[#18181b] text-base leading-tight">SPECTROGRAPHIC PROVENANCE REPORT</h4>
                          <span className="text-[8px] font-mono text-zinc-500 block mt-1">Generated via SpectraForge Workstation Suite v1.0.0</span>
                        </div>
                        <span className="text-[7px] text-zinc-400 bg-zinc-100 px-1.5 py-0.5 rounded uppercase tracking-wider font-semibold">Page 1 of 3</span>
                      </div>

                      <div className="w-full h-[0.5px] bg-zinc-200 my-3" />

                      {/* Metadata profile inside preview */}
                      <div className="bg-zinc-50 border border-zinc-200 rounded p-3 grid grid-cols-2 gap-2 text-[9px] text-zinc-700">
                        <div className="col-span-2 font-bold text-zinc-900 text-[10px] mb-1">DATASET METADATA PROFILE</div>
                        
                        <div>
                          <p className="font-semibold text-zinc-900 mb-0.5">Dataset Index Name:</p>
                          <p className="font-mono text-zinc-600 truncate">{sd.name || "N/A"}</p>
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-900 mb-0.5">Spectroscopic Method:</p>
                          <p className="font-mono text-zinc-600">{sd.technique || "N/A"}</p>
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-900 mb-0.5">Coordinates Count (X, Y):</p>
                          <p className="font-mono text-zinc-600">{sd.x.length} points sampled</p>
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-900 mb-0.5">Styles Profile:</p>
                          <p className="font-mono text-zinc-600">{journalStyleOverride} CSS styling active</p>
                        </div>
                      </div>

                      {/* Spectrum plot preview block */}
                      <div className="mt-4 font-sans text-left">
                        <span className="text-[10px] font-bold text-teal-600 block mb-2 text-left">1. Experimental Waveform Signal & Fitted Curve</span>
                        <div className="bg-zinc-900 border border-zinc-300 w-full aspect-[1.66] rounded overflow-hidden flex items-center justify-center relative">
                          {(() => {
                            const plotUrl = (window as any).getPlotCanvasDataURL ? (window as any).getPlotCanvasDataURL() : null;
                            if (plotUrl) {
                              return <img src={plotUrl} className="w-full h-full object-contain" alt="Spectrum Plot Render Preview" referrerPolicy="no-referrer" />;
                            }
                            return <span className="text-zinc-500 text-[10px]">Real-time waveform outline loader...</span>;
                          })()}
                        </div>
                        <p className="text-[8px] text-zinc-500 mt-2 italic leading-relaxed text-left">
                          Figure 1: Mathematical interpolation curve displaying pristine baseline subtraction models (e.g. SNIP/Shirley/ALS), integrated signal regions, and marked peak states.
                        </p>
                      </div>
                    </div>

                    <div className="border-t border-zinc-100 pt-2 flex justify-between text-[7px] text-zinc-400">
                      <span>SpectraForge Workstation Academic Report - Confidential & Authenticated document</span>
                      <span>Page 1 of 3</span>
                    </div>
                  </div>


                  {/* Virtual PDF Page 2 */}
                  <div className="w-[100%] max-w-[650px] aspect-[1/1.414] bg-white border border-zinc-200 shadow-xl rounded p-[30px] flex flex-col text-zinc-900 justify-between">
                    <div>
                      {/* Stylized top banner */}
                      <div className="w-full h-1 bg-teal-500 mb-4" />

                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-[#18181b] text-base leading-tight">SPECTROGRAPHIC PROVENANCE REPORT</h4>
                          <span className="text-[8px] font-mono text-zinc-500 block mt-1">Generated via SpectraForge Workstation Suite v1.0.0</span>
                        </div>
                        <span className="text-[7px] text-zinc-400 bg-zinc-100 px-1.5 py-0.5 rounded uppercase tracking-wider font-semibold">Page 2 of 3</span>
                      </div>

                      <div className="w-full h-[0.5px] bg-zinc-200 my-3" />

                      {/* Tabular peaks list */}
                      <div className="text-left">
                        <span className="text-[10px] font-bold text-teal-600 block mb-1">2. Multi-Peak Spectral Marks & Molecular Assignments</span>
                        <p className="text-[8px] text-zinc-500 mb-2">The table below details physical peak detections calculated through expert algorithm heuristics and regression fits.</p>
                        
                        <div className="border border-zinc-200 rounded overflow-hidden">
                          <table className="w-full text-left border-collapse text-[8px]">
                            <thead>
                              <tr className="bg-zinc-50 border-b border-zinc-200 text-zinc-700 font-bold">
                                <th className="p-1 px-2.5">Mark ID</th>
                                <th className="p-1">Coordinate (X)</th>
                                <th className="p-1">Absorbance (Y)</th>
                                <th className="p-1">Transition Label</th>
                                <th className="p-1 px-2.5">Confidence</th>
                              </tr>
                            </thead>
                            <tbody>
                              {sd.peaks.length === 0 ? (
                                <tr className="text-zinc-400 italic">
                                  <td colSpan={5} className="p-2 text-center text-[8px]">No custom peak markers detected or loaded for this spectrum.</td>
                                </tr>
                              ) : (
                                sd.peaks.slice(0, 10).map((p, idx) => (
                                  <tr key={idx} className="border-b border-zinc-100 text-zinc-600">
                                    <td className="p-1 px-2.5 font-semibold text-zinc-900">Peak #{idx + 1}</td>
                                    <td className="p-1 font-mono">{p.x.toFixed(3)}</td>
                                    <td className="p-1 font-mono">{p.y.toFixed(4)}</td>
                                    <td className="p-1 text-teal-600 font-semibold">{p.label || "Unassigned"}</td>
                                    <td className="p-1 px-2.5">{(p.confidence * 100).toFixed(0)}%</td>
                                  </tr>
                                ))
                              )}
                              {sd.peaks.length > 10 && (
                                <tr className="text-zinc-400 italic text-[7px]">
                                  <td colSpan={5} className="p-1 text-center bg-zinc-50/50">... and {sd.peaks.length - 10} additional physical peaks cached below visible fold limit ...</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      {/* Active integral regions table */}
                      <div className="mt-5 text-left">
                        <span className="text-[10px] font-bold text-teal-600 block mb-1">3. High-Precision Active Area Integrations</span>
                        <p className="text-[8px] text-zinc-500 mb-2">Provides integration mathematical summaries computed over highlighted boundary segments.</p>
                        
                        <div className="border border-zinc-200 rounded overflow-hidden">
                          <table className="w-full text-left border-collapse text-[8px]">
                            <thead>
                              <tr className="bg-zinc-50 border-b border-zinc-200 text-zinc-700 font-bold">
                                <th className="p-1 px-2.5">Segment Index</th>
                                <th className="p-1">Left Bound (Min)</th>
                                <th className="p-1">Right Bound (Max)</th>
                                <th className="p-1 px-2.5">Computed Area (Y*X)</th>
                              </tr>
                            </thead>
                            <tbody>
                              {sd.integrals.length === 0 ? (
                                <tr className="text-zinc-400 italic">
                                  <td colSpan={4} className="p-2 text-center text-[8px]">No shaded areas or standard mathematical integral slices computed.</td>
                                </tr>
                              ) : (
                                sd.integrals.slice(0, 8).map((intg, idx) => (
                                  <tr key={idx} className="border-b border-zinc-100 text-zinc-600">
                                    <td className="p-1 px-2.5 font-semibold text-zinc-900">Segment {idx + 1}</td>
                                    <td className="p-1 font-mono">{intg.xmin.toFixed(3)}</td>
                                    <td className="p-1 font-mono">{intg.xmax.toFixed(3)}</td>
                                    <td className="p-1 px-2.5 font-mono text-teal-600 font-semibold">{intg.area.toExponential(4)}</td>
                                  </tr>
                                ))
                              )}
                              {sd.integrals.length > 8 && (
                                <tr className="text-zinc-400 italic text-[7px]">
                                  <td colSpan={4} className="p-1 text-center bg-zinc-50/50">... and {sd.integrals.length - 8} more integration records truncated for print layout ...</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-zinc-100 pt-2 flex justify-between text-[7px] text-zinc-400">
                      <span>SpectraForge Workstation Academic Report - Confidential & Authenticated document</span>
                      <span>Page 2 of 3</span>
                    </div>
                  </div>


                  {/* Virtual PDF Page 3 */}
                  <div className="w-[100%] max-w-[650px] aspect-[1/1.414] bg-white border border-zinc-200 shadow-xl rounded p-[30px] flex flex-col text-zinc-900 justify-between">
                    <div>
                      {/* Stylized top banner */}
                      <div className="w-full h-1 bg-teal-500 mb-4" />

                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-[#18181b] text-base leading-tight">SPECTROGRAPHIC PROVENANCE REPORT</h4>
                          <span className="text-[8px] font-mono text-zinc-500 block mt-1">Generated via SpectraForge Workstation Suite v1.0.0</span>
                        </div>
                        <span className="text-[7px] text-zinc-400 bg-zinc-100 px-1.5 py-0.5 rounded uppercase tracking-wider font-semibold">Page 3 of 3</span>
                      </div>

                      <div className="w-full h-[0.5px] bg-zinc-200 my-3" />

                      {/* Optical bandgap semiconductor transition fitting */}
                      <div className="text-left font-sans">
                        <span className="text-[10px] font-bold text-teal-600 block mb-1">4. Semiconductor Bandgap Physics (Tauc Model)</span>
                        {sd.isTauc && sd.taucData ? (
                          <div className="bg-zinc-50 border border-zinc-200 rounded p-2.5 text-[8px] text-zinc-700 space-y-1 block text-left">
                            <div className="flex justify-between"><span className="font-semibold text-zinc-900">Transition Profile:</span><span>{sd.taucData.transition} transition</span></div>
                            <div className="flex justify-between"><span className="font-semibold text-zinc-900">Extrapolated Bandgap (Eg):</span><span className="text-teal-600 font-bold">{sd.taucData.eg.toFixed(3)} eV</span></div>
                            <div className="flex justify-between"><span className="font-semibold text-zinc-900">Linear Slope Regression Formula:</span><span className="font-mono bg-zinc-100 px-1 py-0.5 rounded">y = {sd.taucData.m.toExponential(2)} * x + {sd.taucData.c.toExponential(2)}</span></div>
                          </div>
                        ) : (
                          <p className="text-[8px] text-zinc-400 italic">No solid-state Tauc bandgap optical physics calculations activated for this specimen.</p>
                        )}
                      </div>

                      {/* Processing History steps log list */}
                      <div className="mt-5 text-left font-sans">
                        <span className="text-[10px] font-bold text-teal-600 block mb-1 text-left">5. Technical Processing Pipeline Log History</span>
                        <p className="text-[8px] text-zinc-500 mb-2 text-left">Sequential records logged by the active calibration, smoothing, and baseline correction pipelines.</p>
                        
                        <div className="space-y-1.5 text-left">
                          {sd.history.length === 0 ? (
                            <p className="text-[8px] text-zinc-400 italic text-left">Raw spectroscopic data. No modification trace history found.</p>
                          ) : (
                            sd.history.map((log, index) => (
                              <div key={index} className="bg-slate-50 border border-slate-100 rounded p-1.5 px-2 flex items-start gap-1.5 text-[8px] text-slate-700 leading-normal text-left">
                                <span className="bg-sky-100 text-sky-700 px-1 rounded font-bold shrink-0">{index + 1}</span>
                                <span>{log}</span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-zinc-100 pt-2 flex justify-between text-[7px] text-zinc-400">
                      <span>SpectraForge Workstation Academic Report - Confidential & Authenticated document</span>
                      <span>Page 3 of 3</span>
                    </div>
                  </div>

                </div>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
