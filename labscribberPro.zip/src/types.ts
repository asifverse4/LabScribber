/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PeakData {
  id: string;
  x: number;
  y: number;
  label: string;
  confidence: number;
  dx: number; // visual annotation text offset X (px)
  dy: number; // visual annotation text offset Y (px)
  transition?: string; // spectroscopic molecular transition, e.g., π -> π*
}

export interface IntegralData {
  id: string;
  xmin: number;
  xmax: number;
  area: number;
}

export interface TaucData {
  m: number;
  c: number;
  eg: number;
  x_start: number;
  x_end: number;
  transition: 'direct' | 'indirect';
}

export interface JobsData {
  x_int: number;
  y_int: number;
  m1: number;
  c1: number;
  r2_1: number;
  m2: number;
  c2: number;
  r2_2: number;
}

export interface SpectrumData {
  id: string;
  name: string;
  technique: string;
  x_orig: number[];
  y_orig: number[];
  x: number[];
  y_processed: number[];
  
  color: string;
  visible: boolean;
  
  // Individual stylistic attributes
  lineWidth: number;
  lineStyle: 'solid' | 'dashed' | 'dotted' | 'none';
  marker: 'none' | 'circle' | 'square' | 'triangle' | 'cross';
  markerSize: number;
  
  peaks: PeakData[];
  integrals: IntegralData[];
  
  baseline: number[] | null;
  fitResult: number[] | null;
  fitComponents: number[][] | null; // Each fitted peak's curve
  fitResiduals: number[] | null;
  
  isTauc: boolean;
  taucData: TaucData | null;
  jobsData: JobsData | null;
  
  // State History for robust client-side Undo/Redo State Manager
  undoStack: number[][]; // pushes y_processed states
  redoStack: number[][]; 
  history: string[]; // provenance history
}

export type JournalStyleType = 'ACS' | 'Nature' | 'RSC' | 'Default';
export type ViewLayoutMode = 'Standard Overlay' | 'Waterfall Stack (3D Projection)' | '2D Heatmap / Contour Plot';

export interface PCAOutput {
  refX: number[];
  scores: number[][]; // Row: dataset, Col: PCs
  loadings: number[][]; // PC1 loading curve, PC2 loading curve, ...
  explainedVariance: number[]; // e.g. PC1 variance %, PC2 variance %
}
