/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PeakData, TaucData, JobsData, PCAOutput } from '../types';

// ==========================================
// 1. BASIC LINEAR ALGEBRA UTILS
// ==========================================

export function transpose(m: number[][]): number[][] {
  return m[0].map((_, i) => m.map(row => row[i]));
}

export function multiply(a: number[][], b: number[][]): number[][] {
  const r: number[][] = [];
  const rowsA = a.length;
  const colsA = a[0].length;
  const colsB = b[0].length;

  for (let i = 0; i < rowsA; i++) {
    r[i] = new Array(colsB).fill(0);
    for (let j = 0; j < colsB; j++) {
      let sum = 0;
      for (let k = 0; k < colsA; k++) {
        sum += a[i][k] * b[k][j];
      }
      r[i][j] = sum;
    }
  }
  return r;
}

export function invert(m: number[][]): number[][] {
  const n = m.length;
  const a = m.map((row, i) => [
    ...row,
    ...Array(n).fill(0).map((_, j) => (i === j ? 1 : 0))
  ]);

  for (let i = 0; i < n; i++) {
    let maxRow = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(a[j][i]) > Math.abs(a[maxRow][i])) maxRow = j;
    }
    const temp = a[i];
    a[i] = a[maxRow];
    a[maxRow] = temp;

    const val = a[i][i];
    if (Math.abs(val) < 1e-12) {
      throw new Error("Matrix is singular and non-invertible.");
    }

    for (let j = i; j < 2 * n; j++) a[i][j] /= val;

    for (let j = 0; j < n; j++) {
      if (j !== i) {
        const factor = a[j][i];
        for (let k = i; k < 2 * n; k++) {
          a[j][k] -= factor * a[i][k];
        }
      }
    }
  }

  return a.map(row => row.slice(n));
}

// ==========================================
// 2. SAVITZKY-GOLAY & INTERPOLATION
// ==========================================

export function getSavitzkyGolayCoefficients(windowSize: number, polyOrder: number, deriv: number): number[] {
  const k = Math.floor(windowSize / 2);
  const n = windowSize;
  const t: number[] = [];
  for (let i = -k; i <= k; i++) t.push(i);

  // Construct Vandermonde matrix: X_ij = t_i^j
  const X: number[][] = [];
  for (let i = 0; i < n; i++) {
    X[i] = [];
    for (let j = 0; j <= polyOrder; j++) {
      X[i][j] = Math.pow(t[i], j);
    }
  }

  const Xt = transpose(X);
  const XtX = multiply(Xt, X);
  const XtX_inv = invert(XtX);
  const C = multiply(XtX_inv, Xt);

  // Derivative scaling factor: deriv!
  let scale = 1;
  for (let i = 1; i <= deriv; i++) scale *= i;

  // The row corresponding to the desired derivative is C[deriv]
  return C[deriv].map(val => val * scale);
}

export function savitzkyGolay(y: number[], windowSize: number, polyOrder: number, deriv: number): number[] {
  let size = windowSize;
  if (size % 2 === 0) size += 1;
  if (size < 3) return [...y];
  if (size <= polyOrder) {
    size = polyOrder + 1;
    if (size % 2 === 0) size += 1;
  }

  const half = Math.floor(size / 2);
  const len = y.length;
  const coeffs = getSavitzkyGolayCoefficients(size, polyOrder, deriv);
  const smoothed = new Array(len).fill(0);

  for (let i = 0; i < len; i++) {
    let sum = 0;
    for (let j = -half; j <= half; j++) {
      // Clamp index at boundaries
      const idx = Math.min(Math.max(i + j, 0), len - 1);
      sum += y[idx] * coeffs[j + half];
    }
    smoothed[i] = sum;
  }

  return smoothed;
}

export function movingAverage(y: number[], window: number): number[] {
  const len = y.length;
  const half = Math.floor(window / 2);
  const smoothed = new Array(len).fill(0);
  for (let i = 0; i < len; i++) {
    let sum = 0;
    let count = 0;
    for (let j = -half; j <= half; j++) {
      const idx = i + j;
      if (idx >= 0 && idx < len) {
        sum += y[idx];
        count++;
      }
    }
    smoothed[i] = sum / count;
  }
  return smoothed;
}

export function interpolate(xOrig: number[], yOrig: number[], xTarget: number[]): number[] {
  const f: number[] = [];
  const len = xOrig.length;
  for (let i = 0; i < xTarget.length; i++) {
    const tx = xTarget[i];
    if (tx <= xOrig[0]) {
      f.push(yOrig[0]);
    } else if (tx >= xOrig[len - 1]) {
      f.push(yOrig[len - 1]);
    } else {
      // Find segment
      let low = 0;
      let high = len - 1;
      while (high - low > 1) {
        const mid = Math.floor((low + high) / 2);
        if (xOrig[mid] <= tx) low = mid;
        else high = mid;
      }
      const ratio = (tx - xOrig[low]) / (xOrig[high] - xOrig[low]);
      f.push(yOrig[low] + ratio * (yOrig[high] - yOrig[low]));
    }
  }
  return f;
}

// ==========================================
// 3. BASELINE ESTIMATORS
// ==========================================

/**
 * Shirley Background subtraction for electronic core-level spectra (XPS/UPS).
 * Mathematically: B_i = y_N + (y_1 - y_N) * sum_{j=i}^N(y_j - B_j) / sum_{j=1}^N(y_j - B_j)
 */
export function shirleyBaseline(y: number[], maxIter = 15): number[] {
  const len = y.length;
  if (len < 3) return new Array(len).fill(y[len - 1]);

  let bg = new Array(len).fill(0);
  const yStart = y[0];
  const yEnd = y[len - 1];

  // Initialize line background
  for (let i = 0; i < len; i++) {
    bg[i] = yEnd + (yStart - yEnd) * ((len - 1 - i) / (len - 1));
  }

  for (let iter = 0; iter < maxIter; iter++) {
    const nextBg = [...bg];
    let sumActive = 0;
    for (let i = 0; i < len; i++) {
      sumActive += Math.max(y[i] - bg[i], 0);
    }
    
    if (sumActive < 1e-9) break;

    let accum = 0;
    for (let i = len - 1; i >= 0; i--) {
      accum += Math.max(y[i] - bg[i], 0);
      nextBg[i] = yEnd + (yStart - yEnd) * (accum / sumActive);
    }

    let diff = 0;
    for (let i = 0; i < len; i++) diff += Math.abs(nextBg[i] - bg[i]);
    bg = nextBg;
    if (diff < 1e-4) break;
  }

  return bg;
}

/**
 * Snip (Sensitive Nonlinear Iterative Peak-clipping) baseline estimation.
 * Standard filter in nuclear physics and crystallography, very stable.
 */
export function snipBaseline(y: number[], iterations = 24): number[] {
  const len = y.length;
  const bg = [...y];

  for (let iter = 1; iter <= iterations; iter++) {
    const temp = [...bg];
    for (let i = iter; i < len - iter; i++) {
      const v = (temp[i - iter] + temp[i + iter]) / 2;
      if (v < bg[i]) bg[i] = v;
    }
  }
  return bg;
}

/**
 * Robust ALS (Asymmetric Least Squares) Baseline Correction.
 * To operate client-side at 60fps, we implement a fast penalization smooth loop.
 */
export function alsBaseline(y: number[], lam = 1e5, p = 0.01, limitIter = 10): number[] {
  const len = y.length;
  let baseline = [...y];
  
  // Fast local adaptive envelope smooth approximation of ALS
  for (let iter = 0; iter < limitIter; iter++) {
    const next = [...baseline];
    for (let i = 1; i < len - 1; i++) {
      const avg = (baseline[i - 1] + baseline[i + 1]) / 2;
      const target = y[i];
      
      // Asymmetric weights
      const w = target > baseline[i] ? p : (1 - p);
      
      // Blend smoothing local difference with data target
      next[i] = (1 / (1 + lam)) * avg + (lam / (1 + lam)) * (target * w + baseline[i] * (1 - w));
    }
    baseline = next;
  }
  return baseline;
}

// ==========================================
// 4. SCIENTIFIC ANALYSIS (COGNITIVE STATS)
// ==========================================

export function linearRegression(x: number[], y: number[]): { m: number; c: number; r2: number } {
  const n = x.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0, sumYY = 0;
  for (let i = 0; i < n; i++) {
    sumX += x[i];
    sumY += y[i];
    sumXY += x[i] * y[i];
    sumXX += x[i] * x[i];
    sumYY += y[i] * y[i];
  }

  const denominator = (n * sumXX - sumX * sumX);
  if (denominator === 0) return { m: 0, c: 0, r2: 0 };

  const m = (n * sumXY - sumX * sumY) / denominator;
  const c = (sumY - m * sumX) / n;

  // R-squared
  const meanY = sumY / n;
  let sst = 0, ssr = 0;
  for (let i = 0; i < n; i++) {
    sst += Math.pow(y[i] - meanY, 2);
    ssr += Math.pow(y[i] - (m * x[i] + c), 2);
  }

  const r2 = sst === 0 ? 1 : 1 - (ssr / sst);
  return { m, c, r2 };
}

export function trapezoidalIntegration(x: number[], y: number[]): number {
  let area = 0;
  for (let i = 0; i < x.length - 1; i++) {
    area += 0.5 * (x[i + 1] - x[i]) * (y[i] + y[i + 1]);
  }
  return Math.abs(area);
}

// ==========================================
// 5. UNBIASED PRINCIPAL COMPONENT ANALYSIS
// ==========================================

export function runPCASVD(matrices: number[][], refX: number[]): PCAOutput {
  const mCount = matrices.length; // Number of datasets
  const nCount = matrices[0].length; // Number of wavelength points

  // 1. Mean-centering
  const meanCentered = matrices.map((row) => [...row]);
  const colMeans = new Array(nCount).fill(0);
  for (let j = 0; j < nCount; j++) {
    let sum = 0;
    for (let i = 0; i < mCount; i++) sum += matrices[i][j];
    colMeans[j] = sum / mCount;
    for (let i = 0; i < mCount; i++) meanCentered[i][j] -= colMeans[j];
  }

  // 2. Power Iteration (NIPALS method) to retrieve PC1 and PC2
  const fitPC = (matrix: number[][], pcIndex: number): { score: number[]; loading: number[]; varExplained: number } => {
    let score = new Array(mCount).fill(1); // random init
    let loading = new Array(nCount).fill(0);

    for (let iter = 0; iter < 40; iter++) {
      // a) Loadings = Xt * Score
      for (let j = 0; j < nCount; j++) {
        let sum = 0;
        for (let i = 0; i < mCount; i++) sum += matrix[i][j] * score[i];
        loading[j] = sum;
      }
      // Norm loading
      let normL = 0;
      for (let j = 0; j < nCount; j++) normL += loading[j] * loading[j];
      normL = Math.sqrt(normL) || 1e-9;
      for (let j = 0; j < nCount; j++) loading[j] /= normL;

      // b) Scores = X * Loading
      for (let i = 0; i < mCount; i++) {
        let sum = 0;
        for (let j = 0; j < nCount; j++) sum += matrix[i][j] * loading[j];
        score[i] = sum;
      }
    }

    // Variance
    let varSum = 0;
    for (let i = 0; i < mCount; i++) varSum += score[i] * score[i];

    return { score, loading, varExplained: varSum };
  };

  // Residual matrix
  let resid = meanCentered.map(row => [...row]);
  const allScores: number[][] = []; // Scores for each dataset [datasetIndex][pcIndex]
  const allLoadings: number[][] = []; // Loading vectors [pcIndex][wavelengthIndex]
  const variances: number[] = [];

  const maxPCs = Math.min(mCount, 2);
  let totalVar = 0;
  for (let i = 0; i < mCount; i++) {
    for (let j = 0; j < nCount; j++) {
      totalVar += meanCentered[i][j] * meanCentered[i][j];
    }
  }
  totalVar = totalVar || 1e-9;

  for (let pc = 0; pc < maxPCs; pc++) {
    const { score, loading, varExplained } = fitPC(resid, pc);
    variances.push(varExplained / totalVar);
    allLoadings.push(loading);
    allScores.push(score);

    // Deflate residual matrix
    for (let i = 0; i < mCount; i++) {
      for (let j = 0; j < nCount; j++) {
        resid[i][j] -= score[i] * loading[j];
      }
    }
  }

  // Transpose scores to shape [datasetIndex][pcIndex]
  const scoresOutput: number[][] = Array.from({ length: mCount }, (_, dsIdx) => {
    return Array.from({ length: maxPCs }, (_, pcIdx) => allScores[pcIdx][dsIdx]);
  });

  return {
    refX,
    scores: scoresOutput,
    loadings: allLoadings,
    explainedVariance: variances
  };
}

// ==========================================
// 6. PEAK CURVE FITTING / DECONVOLUTION ENGINE (NELDER-MEAD OPTIMIZATION)
// ==========================================

export function gaussianProfile(x: number, amp: number, cen: number, wid: number): number {
  if (wid <= 0) return 0;
  return amp * Math.exp(-Math.pow(x - cen, 2) / (2 * Math.pow(wid, 2)));
}

export function lorentzianProfile(x: number, amp: number, cen: number, wid: number): number {
  if (wid <= 0) return 0;
  return amp * (wid * wid) / (Math.pow(x - cen, 2) + wid * wid);
}

// Analytical pseudo-Voigt profile blending Gaussian and Lorentzian
export function voigtProfile(x: number, amp: number, cen: number, wid: number, eta = 0.5): number {
  return eta * lorentzianProfile(x, amp, cen, wid) + (1 - eta) * gaussianProfile(x, amp, cen, wid);
}

interface SimplexPoint {
  params: number[];
  error: number;
}

/**
 * Robust Bounded Downhill Simplex (Nelder-Mead) Multi-peak Optimizer
 */
export function fitSpectralPeaks(
  x: number[],
  y: number[],
  initialPeaks: PeakData[],
  profile: 'Gaussian' | 'Lorentzian' | 'Voigt',
  constraints: {
    enforce: boolean;
    centerTol: number;
    widthMin: number;
    widthMax: number;
  }
): { fitResult: number[]; fitComponents: number[][]; fitResiduals: number[] } {
  const peakCount = initialPeaks.length;
  if (peakCount === 0) {
    return { fitResult: null as any, fitComponents: null as any, fitResiduals: null as any };
  }

  // Parameter mapping: Each peak has: [Amplitude, Center, Width, (Voigt: eta [0-1])]
  const dimPerPeak = profile === 'Voigt' ? 4 : 3;
  const numParams = peakCount * dimPerPeak;

  // Build initial guess parameters
  const initialParams: number[] = [];
  initialPeaks.forEach(p => {
    initialParams.push(p.y); // Amplitude
    initialParams.push(p.x); // Center
    initialParams.push((x[x.length - 1] - x[0]) / 35); // Initial FWHM estimate
    if (profile === 'Voigt') initialParams.push(0.5); // Shape factor
  });

  // Target objective function: sum of squared residuals + bounds penalty
  const objective = (params: number[]): number => {
    let penalty = 0;
    
    // Check boundaries and apply strong penalty barriers
    for (let i = 0; i < peakCount; i++) {
      const idx = i * dimPerPeak;
      const amp = params[idx];
      const cen = params[idx + 1];
      const wid = params[idx + 2];
      const shape = profile === 'Voigt' ? params[idx + 3] : 0;

      if (amp < 0) penalty += 1e6 * Math.pow(amp, 2);
      if (wid < constraints.widthMin) {
        penalty += 1e6 * Math.pow(constraints.widthMin - wid, 2);
      }
      if (wid > constraints.widthMax) {
        penalty += 1e6 * Math.pow(wid - constraints.widthMax, 2);
      }

      if (constraints.enforce) {
        const peakOrigX = initialPeaks[i].x;
        const dist = Math.abs(cen - peakOrigX);
        if (dist > constraints.centerTol) {
          penalty += 1e6 * Math.pow(dist - constraints.centerTol, 2);
        }
      }

      if (profile === 'Voigt') {
        if (shape < 0) penalty += 1e6 * Math.pow(shape, 2);
        if (shape > 1) penalty += 1e6 * Math.pow(shape - 1, 2);
      }
    }

    // Calculate sum of squared differences
    let ssr = 0;
    for (let j = 0; j < x.length; j++) {
      const tx = x[j];
      let fitY = 0;
      for (let i = 0; i < peakCount; i++) {
        const idx = i * dimPerPeak;
        const amp = params[idx];
        const cen = params[idx + 1];
        const wid = params[idx + 2];

        if (profile === 'Gaussian') {
          fitY += gaussianProfile(tx, amp, cen, wid);
        } else if (profile === 'Lorentzian') {
          fitY += lorentzianProfile(tx, amp, cen, wid);
        } else {
          fitY += voigtProfile(tx, amp, cen, wid, params[idx + 3]);
        }
      }
      ssr += Math.pow(y[j] - fitY, 2);
    }

    return ssr + penalty;
  };

  // Nelder-Mead simplex solver
  let simplex: SimplexPoint[] = [];

  const createSimplexPoint = (p: number[]): SimplexPoint => ({
    params: p,
    error: objective(p)
  });

  // 1. Initialize Simplex
  simplex.push(createSimplexPoint([...initialParams]));
  for (let i = 0; i < numParams; i++) {
    const pert = [...initialParams];
    // Slightly perturb i-th parameter, handling zero entries appropriately
    pert[i] = pert[i] !== 0 ? pert[i] * 1.05 : 0.05;
    simplex.push(createSimplexPoint(pert));
  }

  const alpha = 1.0; // reflection
  const gamma = 2.0; // expansion
  const rho = 0.5;   // contraction
  const sigma = 0.5; // shrink

  for (let iter = 0; iter < 1200; iter++) {
    // Sort simplex parameters by error
    simplex.sort((a, b) => a.error - b.error);

    const best = simplex[0];
    const worst = simplex[numParams];
    const secondWorst = simplex[numParams - 1];

    // Compute centroid of the best points (excluding the worst)
    const centroid: number[] = new Array(numParams).fill(0);
    for (let i = 0; i < numParams; i++) {
      let sum = 0;
      for (let j = 0; j < numParams; j++) {
        sum += simplex[j].params[i];
      }
      centroid[i] = sum / numParams;
    }

    // Reflection step
    const reflectedParams = centroid.map((c, i) => c + alpha * (c - worst.params[i]));
    const reflected = createSimplexPoint(reflectedParams);

    if (reflected.error < secondWorst.error && reflected.error >= best.error) {
      simplex[numParams] = reflected;
    } else if (reflected.error < best.error) {
      // Expansion step
      const expandedParams = centroid.map((c, i) => c + gamma * (reflectedParams[i] - c));
      const expanded = createSimplexPoint(expandedParams);
      if (expanded.error < reflected.error) {
        simplex[numParams] = expanded;
      } else {
        simplex[numParams] = reflected;
      }
    } else {
      // Contraction step
      const contractParams = centroid.map((c, i) => c + rho * (worst.params[i] - c));
      const contracted = createSimplexPoint(contractParams);
      if (contracted.error < worst.error) {
        simplex[numParams] = contracted;
      } else {
        // Shrink step
        for (let j = 1; j <= numParams; j++) {
          simplex[j].params = simplex[j].params.map((val, i) => best.params[i] + sigma * (val - best.params[i]));
          simplex[j].error = objective(simplex[j].params);
        }
      }
    }

    // Convergence tolerance check
    const variance = simplex[numParams].error - simplex[0].error;
    if (Math.abs(variance) < 1e-6) break;
  }

  // Extract optimal parameters
  const bestParams = simplex[0].params;
  const fitComponents: number[][] = [];
  for (let i = 0; i < peakCount; i++) {
    fitComponents[i] = new Array(x.length).fill(0);
  }

  const fitResult = new Array(x.length).fill(0);
  const fitResiduals = new Array(x.length).fill(0);

  for (let j = 0; j < x.length; j++) {
    const tx = x[j];
    let accum = 0;
    
    for (let i = 0; i < peakCount; i++) {
      const idx = i * dimPerPeak;
      const amp = bestParams[idx];
      const cen = bestParams[idx + 1];
      const wid = bestParams[idx + 2];
      
      let compVal = 0;
      if (profile === 'Gaussian') {
        compVal = gaussianProfile(tx, amp, cen, wid);
      } else if (profile === 'Lorentzian') {
        compVal = lorentzianProfile(tx, amp, cen, wid);
      } else {
        compVal = voigtProfile(tx, amp, cen, wid, bestParams[idx + 3]);
      }
      fitComponents[i][j] = compVal;
      accum += compVal;
    }
    
    fitResult[j] = accum;
    fitResiduals[j] = y[j] - accum;
  }

  return {
    fitResult,
    fitComponents,
    fitResiduals
  };
}

// ==========================================
// 7. MNOVA SPECTRAL HEURISTIC EXPERT SYSTEM
// ==========================================

export function spectralExpertHeuristics(technique: string, x: number): { label: string; confidence: number } {
  const t = technique.toLowerCase();
  
  if (t.includes('1h nmr') || t.includes('nmr')) {
    if (x >= 0.5 && x <= 1.5) return { label: "Alkyl (Aliphatic -CH3)", confidence: 0.95 };
    if (x > 1.5 && x <= 2.5) return { label: "Allylic / α-Carbonyl", confidence: 0.88 };
    if (x > 2.5 && x <= 4.5) return { label: "Alcohols/Halides α-O-CH3", confidence: 0.92 };
    if (x > 4.5 && x <= 6.5) return { label: "Vinylic (=C-H)", confidence: 0.84 };
    if (x > 6.5 && x <= 8.5) return { label: "Aromatic Ring C-H", confidence: 0.98 };
    if (x > 8.5 && x <= 10.5) return { label: "Aldehydic (-CHO)", confidence: 0.99 };
    if (x > 10.5 && x <= 13.0) return { label: "Carboxylic Acid (-COOH)", confidence: 0.96 };
  } else if (t.includes('13c nmr')) {
    if (x >= 0 && x <= 50) return { label: "Saturated Aliphatic (sp3 C)", confidence: 0.96 };
    if (x > 50 && x <= 90) return { label: "Heteroatom attached C-O/C-N", confidence: 0.91 };
    if (x > 90 && x <= 105) return { label: "Acetylenic sp C", confidence: 0.85 };
    if (x > 105 && x <= 150) return { label: "Alkenyl / Aromatic C", confidence: 0.97 };
    if (x > 150 && x <= 185) return { label: "Esters/Amides Carbonyl C", confidence: 0.93 };
    if (x > 185 && x <= 220) return { label: "Aldehyde / Ketone C=O", confidence: 0.99 };
  } else if (t.includes('ftir') || t.includes('raman') || t.includes('infrared')) {
    if (x >= 3200 && x <= 3650) return { label: "O-H / N-H Stretch (H-bonded)", confidence: 0.94 };
    if (x >= 2820 && x <= 3000) return { label: "Aliphatic C-H Stretch", confidence: 0.97 };
    if (x > 3000 && x <= 3150) return { label: "Aromatic / Alkynyl C-H Stretch", confidence: 0.89 };
    if (x >= 2200 && x <= 2260) return { label: "Alkyne / Nitrile -C≡C- / -C≡N", confidence: 0.99 };
    if (x >= 1650 && x <= 1780) return { label: "Carbonyl C=O Stretch (Strong)", confidence: 0.99 };
    if (x >= 1500 && x <= 1650) return { label: "Aromatic C=C / Alkene Stretch", confidence: 0.88 };
    if (x >= 1000 && x <= 1300) return { label: "C-O Single Bond Stretch", confidence: 0.82 };
    if (x >= 600 && x <= 950) return { label: "C-H Out-Of-Plane Bend", confidence: 0.78 };
  } else if (t.includes('uv-vis') || t.includes('uv')) {
    if (x >= 200 && x <= 255) return { label: "Benzene Ring π → π* Transition", confidence: 0.88 };
    if (x > 255 && x <= 350) return { label: "Heteroatom n → π* Conjugation", confidence: 0.82 };
    if (x > 350 && x <= 450) return { label: "Metal-Ligand Charge Transfer", confidence: 0.75 };
    if (x > 450 && x <= 800) return { label: "Extended Chromophore / Plasmons", confidence: 0.85 };
  } else if (t.includes('xps')) {
    if (x >= 284 && x <= 285.5) return { label: "C 1s (sp3/sp2 Carbon C-C)", confidence: 0.98 };
    if (x >= 286 && x <= 287.5) return { label: "C 1s (Ether/Hydroxyl C-O)", confidence: 0.92 };
    if (x >= 288 && x <= 289.5) return { label: "C 1s (Carbonyl C=O / Carboxyl)", confidence: 0.95 };
    if (x >= 531 && x <= 533.5) return { label: "O 1s Core level", confidence: 0.99 };
    if (x >= 398 && x <= 402) return { label: "N 1s Core level", confidence: 0.95 };
  } else if (t.includes('pl') || t.includes('photoluminescence') || t.includes('fluorescence')) {
    if (x >= 350 && x <= 450) return { label: "UV / Near-UV Exciton Decay", confidence: 0.90 };
    if (x > 450 && x <= 600) return { label: "Visible Perovskite / QD Band Edge", confidence: 0.96 };
    if (x > 600 && x <= 850) return { label: "Near-IR Defect / Dopant Emission", confidence: 0.92 };
  } else if (t.includes('xrd') || t.includes('diffraction') || t.includes('x-ray')) {
    if (Math.abs(x - 38.18) <= 1.5) return { label: "Au (111) fcc planes", confidence: 0.99 };
    if (Math.abs(x - 44.39) <= 1.5) return { label: "Au (200) fcc planes", confidence: 0.98 };
    if (Math.abs(x - 64.58) <= 1.5) return { label: "Au (220) fcc planes", confidence: 0.98 };
    if (Math.abs(x - 77.54) <= 1.5) return { label: "Au (311) fcc planes", confidence: 0.99 };
    return { label: "Bragg Diffractplane reflection (hkl)", confidence: 0.80 };
  }
  return { label: "Unassigned Peak Base", confidence: 0.10 };
}
